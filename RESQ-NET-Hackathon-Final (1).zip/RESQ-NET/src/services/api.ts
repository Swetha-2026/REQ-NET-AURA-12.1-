const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5000/api';

export async function api<T>(path:string, options:RequestInit={}) : Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {headers:{'Content-Type':'application/json',...(options.headers||{})}, ...options});
  if(!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}

export const apiRoutes = {
  robots: () => api('/robots'),
  network: () => api('/network'),
  messages: () => api('/messages'),
  alerts: () => api('/alerts'),
  victims: () => api('/victims'),
  missions: () => api('/missions'),
  resqpath: () => api('/resqpath'),
  recover: () => api('/resqpath/recover',{method:'POST'}),
  analytics: () => api('/analytics'),
};
