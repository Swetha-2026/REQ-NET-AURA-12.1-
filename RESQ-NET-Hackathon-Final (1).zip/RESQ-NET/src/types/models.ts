export type Robot = {id:string;status:string;battery:number;signal:number|null;packetLoss:number|null;latency:number|null;position:string;communicationRange:number;role:string};
export type Route = {source:string;destination:string;nodes:string[];cost:number;latency:number;reliability:number;status:string};
export type Message = {id:string;sender:string;receiver:string;priority:string;status:string;timestamp:string;route:string[]};
export type Victim = {id:string;location:string;detectedBy:string;confidence:number;timestamp:string;status:string};
export type Mission = {id:string;name:string;targetZone:string;priority:string;assignedRobots:string[];status:string;progress:number};
