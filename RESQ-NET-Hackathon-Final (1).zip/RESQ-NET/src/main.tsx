import React, { useEffect, useMemo, useState, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity, AlertTriangle, BatteryCharging, Bot, ChevronRight, Globe2, Inbox,
  Layers3, Map, Menu, MessageSquare, Network, Radio, Route, Settings,
  ShieldCheck, Signal, TriangleAlert, X, Zap, Crosshair, Navigation, Wifi, LockKeyhole, UserPlus, LogIn, Eye, EyeOff, Send, Database, CheckCircle2, RadioTower, UserRound,
  Bell, Target, Wand2, ClipboardList, UserCog, Search, Plus, Minus, LocateFixed, Mic, RotateCcw, PanelLeftClose
} from "lucide-react";
import { languages, translations, extraTranslations, type Language } from "./translations";
import "./styles.css";

type RobotStatus = "ONLINE" | "WEAK" | "OFFLINE";
type Robot = { id:string; name:string; role:string; battery:number; rssi:number; latency:number; status:RobotStatus; x:number; y:number };

const robots: Robot[] = [
  {id:"R01",name:"Sentinel One",role:"Scout",battery:94,rssi:-51,latency:38,status:"ONLINE",x:22,y:30},
  {id:"R02",name:"Relay Alpha",role:"Relay",battery:81,rssi:-62,latency:44,status:"ONLINE",x:46,y:23},
  {id:"R03",name:"Pathfinder",role:"Victim Search",battery:57,rssi:-88,latency:129,status:"WEAK",x:69,y:51},
  {id:"R04",name:"Rescue Four",role:"Medical",battery:72,rssi:-69,latency:63,status:"ONLINE",x:31,y:69},
  {id:"R05",name:"Relay Bravo",role:"Relay",battery:88,rssi:-58,latency:41,status:"ONLINE",x:56,y:72},
  {id:"R06",name:"Guardian",role:"Heavy Rescue",battery:63,rssi:-76,latency:91,status:"ONLINE",x:79,y:76}
];

const nav = [
  ["command","command",Radio],["map","map",Map],["robots","robots",Bot],["network","network",Network],
  ["resq","resq",Route],["messages","messages",MessageSquare],["alerts","alerts",AlertTriangle],
  ["victims","victims",Target],["missions","missions",ShieldCheck],["simulation","simulation",Activity],
  ["analytics","analytics",Layers3],["prompt","prompt",Wand2],["profile","profile",UserRound],["settings","settings",Settings]
] as const;

type TKey = keyof typeof translations.en;


type UserRole = "Admin" | "Control Operator" | "Rescue Team" | "Viewer";
type AuthUser = { name:string; operatorId:string; email:string; role:UserRole };

function SplashScreen({language,setLanguage,onEnter}:{language:Language;setLanguage:(v:Language)=>void;onEnter:()=>void}){
  const t = (key:TKey) => extraTranslations[language]?.[key] ?? translations[language]?.[key] ?? translations.en[key];
  return <motion.div className="splashScreen" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} transition={{duration:.45}}>
    <div className="splashSky"/><div className="splashGrid"/><div className="splashSmoke ss1"/><div className="splashSmoke ss2"/>
    <div className="splashBuildings"><i/><i/><i/><i/><i/></div>
    <div className="splashBeam sb1"/><div className="splashBeam sb2"/>
    <div className="splashDrone"><span/><i/><i/><i/><i/></div>
    <div className="splashRobot"><div className="splashRobotGlow"/><Robot3D robot={robots[0]}/><div className="splashScan"/></div>
    <div className="splashHud sh1"><b>R01</b><span>ONLINE</span><small>BAT 94% · RSSI -51 dBm</small></div>
    <div className="splashHud sh2"><b>RESQPATH</b><span>SELF-HEALING</span><small>ROUTE ENGINE READY</small></div>
    <div className="splashTop"><div className="brandMark"><Radio size={18}/></div><div><b>RESQ-NET</b><span>RESILIENT COMMUNICATION NETWORK</span></div></div>
    <div className="splashLanguage"><LanguageSelector language={language} setLanguage={setLanguage}/></div>
    <div className="splashCenter">
      <div className="splashEyebrow"><span/> {t("splashEyebrow")}</div>
      <h1>RESQ<span>-NET</span></h1>
      <h2>{t("splashSubtitle")}</h2>
      <p>{t("splashDescription")}</p>
      <div className="splashActions"><button className="splashEnter" onClick={onEnter}>{t("enterCommandCenter")} <ChevronRight size={18}/></button><div className="splashStatus"><i/>{t("meshOnline")} <b>•</b> 06 {t("activeRobots")}</div></div>
    </div>
    <div className="splashFooter"><span>{t("connectRecoverRescue")}</span><span>SIMULATION / DEMO DATA</span></div>
  </motion.div>
}

function AuthScreen({language,setLanguage,onLogin}:{language:Language;setLanguage:(v:Language)=>void;onLogin:(u:AuthUser)=>void}){
  const t = (key:TKey) => extraTranslations[language]?.[key] ?? translations[language]?.[key] ?? translations.en[key];
  const [mode,setMode]=useState<"login"|"signup">("login");
  const [showPass,setShowPass]=useState(false);
  const [forgot,setForgot]=useState(false);
  const [error,setError]=useState("");
  const [form,setForm]=useState({name:"",operatorId:"operator01",email:"",password:"demo123",role:"Control Operator" as UserRole});
  const update=(k:string,v:string)=>setForm(f=>({...f,[k]:v}));
  const submit=()=>{
    setError("");
    if(forgot){ setError(t("recoveryPrepared")); return; }
    if(mode==="login"){
      if(!form.operatorId || !form.password){setError(t("enterCredentials"));return;}
      const role: UserRole = form.operatorId.toLowerCase().includes("admin") ? "Admin" : form.operatorId.toLowerCase().includes("viewer") ? "Viewer" : form.operatorId.toLowerCase().includes("rescue") ? "Rescue Team" : "Control Operator";
      const user={name:role==="Admin"?"System Admin":role==="Viewer"?"Read Only Viewer":"Swetha R",operatorId:form.operatorId,email:form.email||"operator@resq-net.demo",role};
      localStorage.setItem("resq-auth",JSON.stringify(user)); onLogin(user);
    }else{
      if(!form.name || !form.operatorId || !form.email || !form.password){setError(t("completeFields"));return;}
      const user={name:form.name,operatorId:form.operatorId,email:form.email,role:form.role};
      localStorage.setItem("resq-auth",JSON.stringify(user)); onLogin(user);
    }
  };
  return <div className="authScreen">
    <div className="authScene"><div className="authGrid"/><div className="authSmoke a1"/><div className="authSmoke a2"/><div className="authBuilding ab1"/><div className="authBuilding ab2"/>
      <div className="authRobotWrap"><div className="authRobotGlow"/><Robot3D robot={robots[0]}/><div className="authScanLine"/></div>
      <div className="authDrone"><div/><i/><i/><i/><i/></div>
      <div className="authBeam bA"/><div className="authBeam bB"/>
      <div className="authTelemetry at1"><span>R01</span><b>ONLINE</b><small>BAT 94% · RSSI -51</small></div>
      <div className="authTelemetry at2"><span>RESQPATH</span><b>SELF-HEALING</b><small>ROUTE ENGINE READY</small></div>
      <div className="authBrand"><div className="brandMark"><Radio size={18}/></div><div><b>RESQ-NET</b><span>RESILIENT COMMUNICATION NETWORK</span></div></div>
      <div className="authPitch"><span>DISASTER RESPONSE • ROBOTICS • MESH</span><h1>Connect.<br/><em>Recover.</em><br/>Rescue.</h1><p>When infrastructure fails, rescue robots stay connected through adaptive multi-hop communication.</p><div className="authStatus"><i/> MESH NETWORK OPERATIONAL <b>•</b> 06 ROBOTS</div></div>
    </div>
    <div className="authPanel">
      <div className="authLang"><LanguageSelector language={language} setLanguage={setLanguage}/></div>
      <div className="authPanelInner">
        <div className="authEyebrow"><span/> {t("securePortal")}</div>
        <h2>{forgot?t("resetAccess"):mode==="login"?t("welcomeOperator"):t("createAccount")}</h2>
        <p className="authSub">{forgot?t("recoverySub"):mode==="login"?t("loginSub"):t("signupSub")}</p>
        {!forgot && mode==="signup" && <label>{t("fullName")}<input value={form.name} onChange={e=>update("name",e.target.value)} placeholder="Operator name"/></label>}
        <label>{t("operatorId")}<input value={form.operatorId} onChange={e=>update("operatorId",e.target.value)} placeholder="operator01"/></label>
        {mode==="signup" && !forgot && <label>{t("email")}<input type="email" value={form.email} onChange={e=>update("email",e.target.value)} placeholder="operator@resq-net.demo"/></label>}
        {!forgot && <label>{t("password")}<div className="passBox"><input type={showPass?"text":"password"} value={form.password} onChange={e=>update("password",e.target.value)} placeholder="••••••••"/><button type="button" onClick={()=>setShowPass(v=>!v)}>{showPass?<EyeOff size={16}/>:<Eye size={16}/>}</button></div></label>}
        {mode==="signup" && !forgot && <label>{t("role")}<select value={form.role} onChange={e=>update("role",e.target.value)}><option value="Admin">{t("admin")}</option><option value="Control Operator">{t("controlOperator")}</option><option value="Rescue Team">{t("rescueTeam")}</option><option value="Viewer">{t("viewer")}</option></select></label>}
        {mode==="login" && !forgot && <div className="authRow"><label className="check"><input type="checkbox" defaultChecked/> {t("rememberMe")}</label><button className="textBtn" onClick={()=>setForgot(true)}>{t("forgotPassword")}</button></div>}
        {error && <div className="authError"><TriangleAlert size={15}/>{error}</div>}
        <button className="authSubmit" onClick={submit}>{forgot?<Send size={16}/>:mode==="login"?<LogIn size={16}/>:<UserPlus size={16}/>} {forgot?t("sendRecovery"):mode==="login"?t("loginCommandCenter"):t("createAccount")}<ChevronRight size={16}/></button>
        <div className="demoAccess"><div><span>{t("demoAccess")}</span><b>operator01 / demo123</b></div><button onClick={()=>{setMode("login");update("operatorId","operator01");update("password","demo123");setForgot(false)}}>{t("useDemo")}</button></div>
        <div className="authSwitch">{forgot?<button onClick={()=>setForgot(false)}>← Back to login</button>:mode==="login"?<><span>{t("noAccount")}</span><button onClick={()=>setMode("signup")}>{t("createAccount")}</button></>:<><span>{t("alreadyRegistered")}</span><button onClick={()=>setMode("login")}>{t("login")}</button></>}</div>
        <div className="secureNote"><LockKeyhole size={14}/> {t("prototypeSecurity")}</div>
      </div>
    </div>
  </div>
}

function App(){
  const [auth,setAuth]=useState<AuthUser|null>(()=>{try{return JSON.parse(localStorage.getItem("resq-auth")||"null")}catch{return null}});
  const [entry,setEntry]=useState<"splash"|"auth"|"app">("splash");
  const [page,setPage]=useState("command");
  const [selected,setSelected]=useState("R03");
  const [emergency,setEmergency]=useState(false);
  const [language,setLanguage]=useState<Language>(() => (localStorage.getItem("resq-language") as Language) || "en");
  const [resq,setResq]=useState(false);
  const [menu,setMenu]=useState(false);

  const t = (key:TKey) => extraTranslations[language]?.[key] ?? translations[language]?.[key] ?? translations.en[key];
  const active = robots.find(r=>r.id===selected) ?? robots[2];

  useEffect(()=>{
    localStorage.setItem("resq-language",language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  },[language]);

  if(entry === "splash") return <AnimatePresence mode="wait"><SplashScreen language={language} setLanguage={setLanguage} onEnter={()=>{localStorage.setItem("resq-entry-seen","1");setEntry("auth")}}/></AnimatePresence>;
  if(!auth) return <AuthScreen language={language} setLanguage={setLanguage} onLogin={(u)=>{setAuth(u);setEntry("app")}}/>;
  const visibleNav = auth.role === "Viewer" ? nav.filter(([id])=>!["simulation","prompt"].includes(id)) : auth.role === "Rescue Team" ? nav.filter(([id])=>!["settings","prompt"].includes(id)) : nav;

  return <div className={`app ${emergency?"emergency":""}`}>
    <div className="scene">
      <div className="skyGlow"/><div className="smoke s1"/><div className="smoke s2"/>
      <div className="fire f1"/><div className="fire f2"/><div className="ruin ruin1"/><div className="ruin ruin2"/>
      <div className="grid"/><div className="scan"/><div className="dust"/>
      {robots.map(r=><RobotMarker key={r.id} robot={r} selected={selected===r.id} onClick={()=>{setSelected(r.id);setPage("map")}}/>)}
      <div className="victim">+</div>
      <div className="station"><div className="stationCore"/><span>{t("control")}</span></div>
      <svg className="links" viewBox="0 0 100 100" preserveAspectRatio="none">
        <line x1="22" y1="30" x2="46" y2="23"/><line x1="46" y1="23" x2="69" y2="51" className={resq?"recovered":""}/>
        <line x1="69" y1="51" x2="56" y2="72" className={resq?"recovered":""}/><line x1="56" y1="72" x2="79" y2="76"/>
        <line x1="56" y1="72" x2="46" y2="23"/>
      </svg>
    </div>

    <header className="topbar">
      <div className="brand"><div className="brandMark"><Radio size={18}/></div><div><b>RESQ-NET</b><span>SELF-HEALING RESCUE NETWORK</span></div></div>
      <div className="topStatus"><span className="pulse"/>{t("meshOnline")}<i/>{String(robots.length).padStart(2,"0")} {t("activeRobots")}<i/>14 {t("routes")}</div>
      <div className="actions">
        <LanguageSelector language={language} setLanguage={setLanguage}/>
        <button className={emergency?"danger activeBtn":"danger"} onClick={()=>setEmergency(v=>!v)}><TriangleAlert size={15}/>{t("emergency")}</button>
        <button className="avatar" title={`${auth.name} • ${auth.role}`} onClick={()=>{localStorage.removeItem("resq-auth");setAuth(null);setEntry("splash")}}>{auth.name.slice(0,2).toUpperCase()}</button>
      </div>
    </header>

    <div className="hudTitle"><span>{t("commandCenter")}</span><strong>{new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</strong></div>

    <aside className="desktopSidebar">
      <div className="sidebarSectionLabel">MISSION CONTROL</div>
      {visibleNav.map(([id,key,Icon])=><button key={id} className={page===id?"active":""} onClick={()=>setPage(id)}><Icon size={17}/><span>{t(key as TKey)}</span>{id==="resq"&&<em>LIVE</em>}{id==="alerts"&&<b>02</b>}</button>)}
      <div className="sidebarBottom"><div className="operatorMini"><div className="avatarMini">{auth.name.slice(0,2).toUpperCase()}</div><div><b>{auth.name}</b><span>{auth.role}</span></div></div><button onClick={()=>{localStorage.removeItem("resq-auth");setAuth(null);setEntry("splash")}}><PanelLeftClose size={15}/> LOG OUT</button></div>
    </aside>

    <AnimatePresence>{menu && <motion.div className="mobileNav" initial={{x:-30,opacity:0}} animate={{x:0,opacity:1}} exit={{x:-30,opacity:0}}>
      {visibleNav.map(([id,key,Icon])=><button key={id} className={page===id?"active":""} onClick={()=>{setPage(id);setMenu(false)}}><Icon size={17}/>{t(key as TKey)}</button>)}
    </motion.div>}</AnimatePresence>

    <main className="content"><AnimatePresence mode="wait"><motion.div key={page} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.28}}>
      {page==="command"&&<CommandPage t={t} active={active} emergency={emergency} resq={resq} setResq={setResq} setPage={setPage}/>}
      {page==="map"&&<MapPage t={t} selected={selected} setSelected={setSelected}/>}
      {page==="robots"&&<RobotsPage t={t} selected={selected} setSelected={setSelected}/>}
      {page==="network"&&<NetworkPage t={t} resq={resq}/>}
      {page==="resq"&&<ResqPage t={t} resq={resq} setResq={setResq}/>}
      {page==="messages"&&<MessagesPage t={t}/>}
      {page==="alerts"&&<AlertsPage t={t}/>}
      {page==="victims"&&<VictimsPage t={t} setPage={setPage}/>}
      {page==="missions"&&<MissionsPage t={t}/>}
      {page==="simulation"&&<SimulationPage t={t}/>}
      {page==="analytics"&&<AnalyticsPage t={t}/>}
      {page==="prompt"&&<PromptPage t={t}/>}
      {page==="profile"&&<ProfilePage t={t} auth={auth}/>}
      {page==="settings"&&<SettingsPage t={t} language={language} setLanguage={setLanguage}/>}
    </motion.div></AnimatePresence></main>

    <nav className="dock"><button className="dockMenu" onClick={()=>setMenu(v=>!v)}>{menu?<X size={20}/>:<Menu size={20}/>}</button>
      {visibleNav.slice(0,7).map(([id,key,Icon])=><button key={id} className={page===id?"dockItem selected":"dockItem"} onClick={()=>setPage(id)}><Icon size={18}/><span>{t(key as TKey)}</span></button>)}
    </nav>
    <div className="simBadge">{t("simulationData")}</div>
  </div>
}

function LanguageSelector({language,setLanguage}:{language:Language;setLanguage:(v:Language)=>void}){
  const current=languages.find(l=>l.code===language)!;
  return <div className="languageWrap"><Globe2 size={15}/><select value={language} onChange={e=>setLanguage(e.target.value as Language)} aria-label="Language">
    {languages.map(l=><option key={l.code} value={l.code}>{l.native} — {l.label}</option>)}
  </select><span className="chev">⌄</span></div>
}

function RobotMarker({robot,selected,onClick}:{robot:Robot;selected:boolean;onClick:()=>void}){
  return <button className={`robotMarker ${robot.status.toLowerCase()} ${selected?"selected":""}`} style={{left:`${robot.x}%`,top:`${robot.y}%`}} onClick={onClick}>
    <div className="robotDot"><Bot size={16}/></div><span>{robot.id}</span><em/>
  </button>
}

type TFn = (key:TKey)=>string;
function PageShell({title,sub,children,t}:{title:string;sub:string;children:ReactNode;t:TFn}){
  return <section className="page"><div className="pageTitle"><div><span className="eyebrow"><span/>{t("command") === "Command" ? "RESQ-NET SYSTEM" : "RESQ-NET SYSTEM"}</span><h1>{title}</h1><p>{sub}</p></div><div className="pageTime"><span className="pulse"/>{t("live")}</div></div>{children}</section>
}

function CommandPage({t,active,emergency,resq,setResq,setPage}:{t:TFn;active:Robot;emergency:boolean;resq:boolean;setResq:(v:boolean)=>void;setPage:(v:string)=>void}){
  return <section className="commandPage">
    <div className="heroCopy">
      <div className="eyebrow"><span/>{t("liveIncident")}</div>
      <div className="heroKicker">AUTONOMOUS EMERGENCY RESPONSE • MESH ONLINE</div>
      <h1>{t("hero")}</h1>
      <p>{t("heroSub")}</p>
      <div className="heroBtns"><button className="primary" onClick={()=>setPage("resq")}><Route size={17}/>{t("openResq")}<ChevronRight size={17}/></button><button className="outline" onClick={()=>setPage("map")}><Map size={17}/>{t("liveMap")}</button></div>
      <div className="metrics"><Metric label={t("networkHealth")} value={resq?"96":"92"} unit="%"/><Metric label={t("meshCoverage")} value="87" unit="%"/><Metric label={t("pending")} value="08" unit=""/><Metric label={t("alerts")} value={emergency?"05":"02"} unit=""/></div>
    </div>

    <div className="heroRobotStage" aria-label="3D rescue robot scene">
      <div className="horizonGlow"/>
      <div className="building b1"/><div className="building b2"/><div className="building b3"/>
      <div className="heroSmoke hs1"/><div className="heroSmoke hs2"/>
      <div className="drone3D"><div className="droneBody"/><i/><i/><i/><i/><span>R-NET DRONE</span></div>
      <div className="beam beam1"/><div className="beam beam2"/>
      <div className="heroRobotBack back1"><RobotMini label="R04"/></div>
      <div className="heroRobotBack back2"><RobotMini label="R05"/></div>
      <div className="heroRobotBack back3"><RobotMini label="R02"/></div>
      <div className="heroRobotMain"><Robot3D robot={active}/><div className="groundRing"/><div className="pathTrail"><i/><i/><i/><i/><i/></div></div>
      <div className="routeFloat"><Route size={13}/><span>RESQPATH</span><b>{resq?"SELF-HEALED":"MONITORING"}</b></div>
      <div className="scanHUD"><span>SECTOR 07</span><b>LIVE TRACKING</b><i/></div>
    </div>

    <div className="floatingInfo"><div className="panelHead"><span>{t("selectedRobot")}</span><b>{active.id}</b></div>
      <Robot3D robot={active}/>
      <div className="robotName"><div><h3>{active.name}</h3><span>{active.role}</span></div><Badge status={active.status}/></div>
      <div className="telemetry"><T label={t("battery")} value={`${active.battery}%`} icon={<BatteryCharging/>}/><T label={t("rssi")} value={`${active.rssi} dBm`} icon={<Signal/>}/><T label={t("latency")} value={`${active.latency} ms`} icon={<Activity/>}/><T label={t("range")} value="240 m" icon={<Navigation/>}/></div>
      <button className="fullBtn" onClick={()=>setPage("robots")}>{t("fullTelemetry")}</button>
    </div>
    <div className="incident"><span className="liveDot"/>{resq?t("recovered"):t("degraded")}</div>
  </section>
}

function RobotMini({label}:{label:string}){
  return <div className="miniRobot"><div className="miniBody"><span className="miniEye"/><span className="miniEye"/></div><i className="miniWheel w1"/><i className="miniWheel w2"/><i className="miniWheel w3"/><i className="miniWheel w4"/><b>{label}</b></div>
}

function Robot3D({robot}:{robot:Robot}){
  return <div className="robot3DWrap"><div className="radarRing"/><div className="robot3D">
    <div className="antenna"/><div className="sensor"><span/></div><div className="chassis"><div className="panel p1"/><div className="panel p2"/><div className="light l1"/><div className="light l2"/></div>
    <div className="wheel w1"/><div className="wheel w2"/><div className="wheel w3"/><div className="wheel w4"/>
  </div><div className="robotScan"/><div className="robotTag">{robot.id} • {robot.status}</div></div>
}

function Metric({label,value,unit}:{label:string;value:string;unit:string}){return <div><span>{label}</span><strong>{value}<small>{unit}</small></strong></div>}
function T({label,value,icon}:{label:string;value:string;icon:ReactNode}){return <div className="t"><span>{icon}{label}</span><b>{value}</b></div>}
function Badge({status}:{status:RobotStatus}){return <span className={`badge ${status.toLowerCase()}`}><i/>{status}</span>}

function MapPage({t,selected,setSelected}:{t:TFn;selected:string;setSelected:(v:string)=>void}){
  const [layers,setLayers]=useState({links:true,danger:true,victims:true,labels:true});
  const [zoom,setZoom]=useState(1);
  const active=robots.find(r=>r.id===selected)||robots[0];
  return <PageShell t={t} title={t("map").toUpperCase()} sub="Cinematic disaster terrain • robot positions • mesh communication • live hazards"><div className="tacticalMapWrap">
    <div className="tacticalMapToolbar"><div className="mapSearch"><Search size={15}/><input placeholder="Search robot, sector, victim…"/></div><div className="mapTools"><button onClick={()=>setZoom(z=>Math.min(1.35,z+.1))}><Plus size={15}/></button><button onClick={()=>setZoom(z=>Math.max(.8,z-.1))}><Minus size={15}/></button><button onClick={()=>setZoom(1)}><RotateCcw size={14}/></button><button><LocateFixed size={15}/></button></div></div>
    <div className="tacticalMap" style={{transform:`scale(${zoom})`}}>
      <div className="mapImage"/><div className="mapVignette"/><div className="mapRoad roadA"/><div className="mapRoad roadB"/><div className="mapRoad roadC"/>
      {layers.danger&&<><div className="hazard h1">HIGH RISK ZONE</div><div className="hazard h2">CRITICAL ZONE</div></>}
      {layers.victims&&<><div className="victimPin vp1"><Target size={15}/><b>V-024</b></div><div className="victimPin vp2"><Target size={14}/><b>V-031</b></div></>}
      {layers.links&&<svg className="mapLinks" viewBox="0 0 100 100" preserveAspectRatio="none"><line x1="22" y1="30" x2="46" y2="23"/><line x1="46" y1="23" x2="69" y2="51" className="weakLink"/><line x1="69" y1="51" x2="56" y2="72" className="brokenLink"/><line x1="56" y1="72" x2="79" y2="76"/><line x1="56" y1="72" x2="46" y2="23"/></svg>}
      {robots.map(r=><RobotMarker key={r.id} robot={r} selected={selected===r.id} onClick={()=>setSelected(r.id)}/>) }
      {layers.labels&&<div className="controlMapPin"><RadioTower size={18}/><b>CONTROL</b><span>COMMAND HUB</span></div>}
      <div className="mapCompass">N<div/></div><div className="mapScale">0&nbsp;&nbsp;100&nbsp;&nbsp;200&nbsp;&nbsp;500 m</div>
      <div className="mapLegendNew"><span><i className="ok"/>Healthy</span><span><i className="warn"/>Weak</span><span><i className="bad"/>Broken</span></div>
      <div className="layerPanel"><label><input type="checkbox" checked={layers.links} onChange={e=>setLayers(x=>({...x,links:e.target.checked}))}/> Network Links</label><label><input type="checkbox" checked={layers.danger} onChange={e=>setLayers(x=>({...x,danger:e.target.checked}))}/> Danger Zones</label><label><input type="checkbox" checked={layers.victims} onChange={e=>setLayers(x=>({...x,victims:e.target.checked}))}/> Victims</label><label><input type="checkbox" checked={layers.labels} onChange={e=>setLayers(x=>({...x,labels:e.target.checked}))}/> Robot Labels</label></div>
    </div>
    <aside className="mapDetail"><div className="panelHead"><span>SELECTED ROBOT</span><b>{active.id}</b></div><Robot3D robot={active}/><div className="mapRobotTitle"><div><h2>{active.name}</h2><span>{active.role}</span></div><Badge status={active.status}/></div><div className="mapTelemetry"><T label="Battery" value={`${active.battery}%`} icon={<BatteryCharging/>}/><T label="RSSI" value={`${active.rssi} dBm`} icon={<Signal/>}/><T label="Packet Loss" value={active.status==="OFFLINE"?"--":"2.1%"} icon={<Wifi/>}/><T label="Latency" value={`${active.latency} ms`} icon={<Activity/>}/><T label="Range" value="120 m" icon={<Navigation/>}/><T label="Position" value={`Zone ${active.id==="R04"?"C":"B"}`} icon={<LocateFixed/>}/></div><div className="mapRoute"><span>CURRENT ROUTE</span><b>{active.id} → R02 → R01 → CONTROL</b></div><div className="mapButtons"><button className="primary"><Crosshair size={14}/> Track Robot</button><button className="outline"><MessageSquare size={14}/> Send Message</button><button className="outline"><Route size={14}/> Change Route</button><button className="danger"><TriangleAlert size={14}/> Emergency Stop</button></div></aside>
  </div></PageShell>
}

function RobotsPage({t,selected,setSelected}:{t:TFn;selected:string;setSelected:(v:string)=>void}){
  const [detail,setDetail]=useState<Robot|null>(robots.find(r=>r.id===selected)||robots[0]);
  const [noNetwork,setNoNetwork]=useState(false);
  const [sms,setSms]=useState("");
  const [sent,setSent]=useState(false);
  const open=(r:Robot)=>{setSelected(r.id);setDetail(r);setSent(false)};
  return <PageShell t={t} title={t("fleet")} sub="Access robot telemetry, mission state and communication status"><div className="robotAccessLayout"><div className="robotGrid">{robots.map(r=><motion.button whileHover={{y:-5,rotateX:2}} key={r.id} className={`robotCard ${selected===r.id?"chosen":""}`} onClick={()=>open(r)}>
    <Robot3D robot={r}/><div className="robotCardTop"><b>{r.id}</b><Badge status={r.status}/></div><h3>{r.name}</h3><p>{r.role}</p><div className="bar"><i style={{width:`${r.battery}%`}}/></div><div className="robotStats"><span>{t("battery")} <b>{r.battery}%</b></span><span>{t("rssi")} <b>{r.rssi}</b></span><span>{t("latency")} <b>{r.latency}ms</b></span></div><span className="accessHint">OPEN ROBOT INFORMATION →</span>
  </motion.button>)}</div>
  {detail&&<aside className="robotAccessPanel"><div className="accessHead"><div><span>ROBOT ACCESS / TELEMETRY</span><h2>{detail.id} <small>{detail.name}</small></h2></div><button onClick={()=>setDetail(null)}><X size={17}/></button></div><div className="accessRobot"><Robot3D robot={detail}/><div><Badge status={detail.status}/><p>{detail.role} • Zone {detail.id==="R04"?"C":"B"}</p></div></div><div className="accessGrid"><T label={t("battery")} value={`${detail.battery}%`} icon={<BatteryCharging/>}/><T label={t("rssi")} value={`${detail.rssi} dBm`} icon={<Signal/>}/><T label={t("latency")} value={`${detail.latency} ms`} icon={<Activity/>}/><T label="PACKET LOSS" value={detail.status==="OFFLINE"?"--":"1.2%"} icon={<Wifi/>}/><T label="RANGE" value="120 m" icon={<Navigation/>}/><T label="ROLE" value={detail.role} icon={<Bot/>}/></div>
    <div className={`networkState ${noNetwork?"offline":"online"}`}><div><RadioTower size={18}/><div><b>{noNetwork?"NO NETWORK / OFFLINE MODE":"MESH LINK AVAILABLE"}</b><span>{noNetwork?"SMS-like store-and-forward is active":"Direct robot messaging is available"}</span></div></div><button onClick={()=>{setNoNetwork(v=>!v);setSent(false)}}>{noNetwork?"RESTORE NETWORK":"SIMULATE NO NETWORK"}</button></div>
    <div className="robotSms"><div className="smsHead"><span><MessageSquare size={15}/> ROBOT MESSAGE</span><b>{noNetwork?"STORE & FORWARD":"LIVE MESH"}</b></div><div className="smsBody"><div className="smsBubble incoming"><b>{detail.id}</b><span>{noNetwork?"Telemetry stored locally. No network route is available.":"CONTROL → ROBOT channel ready. Send mission or status request."}</span><time>NOW</time></div>{sent&&<div className="smsBubble outgoing"><b>CONTROL</b><span>{sms||"Status request"}</span><time>DELIVERED ✓</time></div>}</div><div className="smsComposer"><input value={sms} onChange={e=>setSms(e.target.value)} placeholder={noNetwork?"Type SMS — will forward when network returns":"Send instruction to robot..."}/><button onClick={()=>{setSent(true);if(!noNetwork)setSms("")}}><Send size={15}/></button></div>{noNetwork&&<div className="storeNote"><Database size={14}/> MESSAGE STORED LOCALLY • WILL FORWARD AUTOMATICALLY AFTER LINK RECOVERY</div>}</div>
    <div className="accessActions"><button className="primary"><Crosshair size={15}/> TRACK</button><button className="outline"><Navigation size={15}/> CHANGE ROUTE</button><button className="danger"><TriangleAlert size={15}/> EMERGENCY STOP</button></div>
  </aside>}</div></PageShell>
}
function NetworkPage({t,resq}:{t:TFn;resq:boolean}){
  return <PageShell t={t} title={t("mesh")} sub={t("meshSub")}><div className="networkPanel"><div className="networkCanvas"><div className="coreNode"><Radio/><b>{t("control")}</b><small>{t("commandHub")}</small></div>
    {robots.map(r=><div key={r.id} className="netNode" style={{left:`${r.x}%`,top:`${r.y}%`}}><div><Bot size={18}/><b>{r.id}</b></div><small>{r.role}</small></div>)}
    <div className={`routeBanner ${resq?"good":""}`}><Zap size={15}/>{resq?t("selfHealing"):t("monitoring")}</div></div>
    <div className="sideStats"><Stat label={t("packetDelivery")} value={resq?"98.7":"94.2"} suffix="%"/><Stat label={t("avgLatency")} value="61" suffix="ms"/><Stat label={t("packetLoss")} value={resq?"1.3":"5.8"} suffix="%"/><Stat label={t("activeRoutes")} value="14" suffix=""/></div>
  </div></PageShell>
}

function Stat({label,value,suffix}:{label:string;value:string;suffix:string}){return <div className="stat"><span>{label}</span><b>{value}<small>{suffix}</small></b><div className="tinyGraph">{[1,2,3,4,5,6].map(i=><i key={i}/>)}</div></div>}

function ResqPage({t,resq,setResq}:{t:TFn;resq:boolean;setResq:(v:boolean)=>void}){
  const steps=[t("detect"),t("measure"),t("selectRelay"),t("reroute"),t("confirm")];
  return <PageShell t={t} title={t("resqTitle")} sub={t("resqSub")}><div className="resqLayout"><div className="routeStage"><div className="routeHeader"><div><span className="eyebrow"><span/>{t("routeEngine")}</span><h2>{resq?t("recoveredShort"):t("degradedShort")}</h2></div><button className={resq?"primary":"danger"} onClick={()=>setResq(!resq)}>{resq?t("resetFailure"):t("simulateFailure")}</button></div>
    <div className="routeDiagram"><Node id="CONTROL" x="10%" y="50%" core/><Node id="R02" x="33%" y="30%"/><Node id="R03" x="56%" y="50%" warn={!resq}/><Node id="R05" x="56%" y="75%" good={resq}/><Node id="R04" x="80%" y="30%"/>
      <div className={`routeLine l1 ${resq?"on":""}`}/><div className={`routeLine l2 ${resq?"broken":""}`}/><div className={`routeLine l3 ${resq?"on":""}`}/><div className={`routeLine l4 ${resq?"on":""}`}/>
      {resq&&<motion.div className="packet" animate={{left:["10%","33%","56%","56%","80%"],top:["50%","30%","75%","75%","30%"]}} transition={{duration:3,repeat:Infinity,ease:"linear"}}/>}
    </div>
    <div className="steps">{steps.map((s,i)=><div className={resq?"done":""} key={s}><b>0{i+1}</b><span>{s}</span>{resq&&<ShieldCheck size={15}/>}</div>)}</div></div>
    <div className="routeLog"><h3>{t("routeLog")}</h3><Log text="R03 RSSI crossed threshold" type="warn" t={t}/><Log text="Packet loss increased to 18.4%" type="warn" t={t}/><Log text="R05 selected as relay" type="ok" t={t}/><Log text="New path: R03 → R05 → R02 → CONTROL" type="ok" t={t}/><Log text={t("routeRecovered")} type="ok" t={t}/></div>
  </div></PageShell>
}
function Node({id,x,y,core,warn,good}:{id:string;x:string;y:string;core?:boolean;warn?:boolean;good?:boolean}){return <div className={`routeNode ${core?"core":""} ${warn?"warn":""} ${good?"good":""}`} style={{left:x,top:y}}><div><Radio size={16}/>{id}</div><small>{core?"HQ":warn?"WEAK":"RELAY READY"}</small></div>}
function Log({text,type,t}:{text:string;type:"warn"|"ok";t:TFn}){return <div className="log"><i className={type}/><span>{text}</span><time>{t("now")}</time></div>}

function MessagesPage({t}:{t:TFn}){
  const messages=["MEDICAL TEAM → R03","VICTIM COORDINATES → R05","EVAC ROUTE → R04","SUPPLY DROP → R06","ACK REQUEST → R02"];
  return <PageShell t={t} title={t("messageCenter")} sub={t("messageSub")}><div className="messageGrid"><div className="queue"><div className="queueHead"><span>{t("outbound")}</span><b>08</b></div>{messages.map((m,i)=><div className="msg" key={m}><span className={`priority p${i}`}>P{i<2?0:i+1}</span><div><b>{m}</b><small>{i<2?t("critical"):t("queued")}</small></div><time>{i*7+2}s</time></div>)}</div><div className="delivery"><div className="deliveryIcon"><Inbox/></div><h2>98.7%</h2><p>{t("reliable")}</p><div className="deliveryBars">{Array.from({length:10},(_,i)=><i key={i}/>)}</div><button className="outline">{t("audit")}</button></div></div></PageShell>
}

function AlertsPage({t}:{t:TFn}){
  const alerts=["R03 signal degradation detected","Victim beacon detected — Sector 07","Bridge vibration above threshold","R05 relay link stable","Emergency mode armed"];
  return <PageShell t={t} title={t("alertConsole")} sub={t("alertSub")}><div className="alertList">{alerts.map((a,i)=><div className={`alertRow ${i<2?"critical":""}`} key={a}><div className="alertIcon"><AlertTriangle size={18}/></div><div><b>{a}</b><span>{i<2?t("attention"):t("monitoringActive")}</span></div><time>{i+1} min ago</time></div>)}</div></PageShell>
}

function MissionsPage({t}:{t:TFn}){
  const missions=[["M-104","SECTOR 07 VICTIM SEARCH","R03 + R05","68%"],["M-105","MEDICAL SUPPLY RUN","R04","42%"],["M-106","RELAY EXPANSION","R02 + R06","81%"]];
  return <PageShell t={t} title={t("missionsTitle")} sub={t("missionsSub")}><div className="missionGrid">{missions.map(m=><div className="mission" key={m[0]}><span>{m[0]}</span><h3>{m[1]}</h3><p>{m[2]}</p><div className="progress"><i style={{width:m[3]}}/></div><b>{m[3]}</b></div>)}</div></PageShell>
}

function SimulationPage({t}:{t:TFn}){
  const [running,setRunning]=useState(false);
  return <PageShell t={t} title={t("simulationTitle")} sub={t("simulationSub")}><div className="simPanel"><div><span className="eyebrow"><span/>{t("scenario")}</span><h2>{t("failureDrill")}</h2><p>{t("simulationCopy")}</p><div className="scenarioOptions"><button className="selected"><Bot/>R03 OFFLINE</button><button><Signal/>RSSI -95 dBm</button><button><MessageSquare/>18% PACKET LOSS</button></div><button className="primary" onClick={()=>setRunning(v=>!v)}>{running?t("stop"):t("run")}<Zap size={16}/></button></div><div className={`simOrb ${running?"running":""}`}><div className="orbRing rA"/><div className="orbRing rB"/><div className="orbCore"><Activity/></div><span>{running?t("recovering"):t("ready")}</span></div></div></PageShell>
}

function AnalyticsPage({t}:{t:TFn}){return <PageShell t={t} title={t("analyticsTitle")} sub={t("analyticsSub")}><div className="analytics"><Stat label={t("deliverySuccess")} value="98.7" suffix="%"/><Stat label="AVG RSSI" value="-64" suffix="dBm"/><Stat label={t("avgLatency")} value="61" suffix="ms"/><Stat label={t("coverage")} value="87" suffix="%"/></div><div className="chart"><div className="chartHead"><h3>{t("last30")}</h3><span>{t("live")}</span></div><div className="bars">{Array.from({length:30},(_,i)=><i key={i} style={{height:`${35+((i*17)%55)}%`}}/>)}</div><div className="chartLabels"><span>-30m</span><span>-20m</span><span>-10m</span><span>{t("now")}</span></div></div></PageShell>}


function VictimsPage({t,setPage}:{t:TFn;setPage:(v:string)=>void}){
  const victims=[{id:"V-024",zone:"B-14",robot:"R03",confidence:94,status:"UNRESCUED",dist:"74 m"},{id:"V-031",zone:"C-08",robot:"R05",confidence:88,status:"PENDING",dist:"112 m"},{id:"V-019",zone:"A-22",robot:"R02",confidence:97,status:"RESCUED",dist:"—"}];
  return <PageShell t={t} title="VICTIM DETECTION" sub="Sensor detections prioritized above routine telemetry"><div className="victimGrid">{victims.map(v=><motion.div whileHover={{y:-4}} className={`victimCard ${v.status.toLowerCase()}`} key={v.id}><div className="victimCardTop"><Target size={20}/><span>{v.status}</span></div><h2>{v.id}</h2><p>Detected by <b>{v.robot}</b> • Zone {v.zone}</p><div className="victimMetrics"><div><span>CONFIDENCE</span><b>{v.confidence}%</b></div><div><span>NEAREST ROBOT</span><b>{v.dist}</b></div></div><div className="victimActions"><button className="outline" onClick={()=>setPage("map")}><Map size={14}/> VIEW LOCATION</button><button className="primary"><Bot size={14}/> DISPATCH ROBOT</button><button className="danger"><MessageSquare size={14}/> EMERGENCY MESSAGE</button></div></motion.div>)}</div></PageShell>
}

function PromptPage({t}:{t:TFn}){
  const [prompt,setPrompt]=useState(`Build RESQ-NET — Resilient Communication Network for Disaster-Response Robots.\n\nProject Overview:\nCreate a premium disaster-response robotics command center with multilingual support, role-based access, live tactical map, robot telemetry, ad-hoc mesh networking, multi-hop communication, priority messaging, store-and-forward, dynamic routing and ResQPath self-healing route recovery.\n\nDemo Scenario:\nR03 communication fails → analyse battery/RSSI/packet loss/latency/distance/hops → select R05 as relay → recover route R04 → R05 → R02 → CONTROL → deliver critical victim message.\n\nUI/UX:\nDark cinematic emergency operations interface, realistic robot visuals, tactical disaster map, subtle glass panels, cyan/green/red status language, responsive layouts, accessible emergency controls, reduced-motion option, Arabic RTL.\n\nTech:\nReact + TypeScript + Flask + SQLite. Provide reusable components, API services, mock/demo data, authentication architecture and WebSocket-ready real-time state.`);
  const [saved,setSaved]=useState<string[]>([]);
  const generate=()=>setPrompt(p=>p+`\n\nGenerated at ${new Date().toLocaleTimeString()}: Add testing, deployment, accessibility, security UX, API contracts, analytics, notification center and future PostgreSQL migration.`);
  return <PageShell t={t} title="PROMPT GENERATOR" sub="Generate structured build prompts for future AI coding/design assistants"><div className="promptLayout"><div className="promptForm"><h3>PROJECT CONFIGURATION</h3>{["Project Name","Project Description","UI Style","Color Theme","Pages","Features","Tech Stack","Target Platform","User Type","Special Requirements"].map((x,i)=><label key={x}>{x}<input defaultValue={i===0?"RESQ-NET":""} placeholder={x}/></label>)}<button className="primary" onClick={generate}><Wand2 size={15}/> GENERATE PROMPT</button></div><div className="promptEditor"><div className="editorHead"><span>GENERATED PROMPT</span><div><button onClick={()=>navigator.clipboard?.writeText(prompt)}>COPY PROMPT</button><button onClick={generate}>REGENERATE</button><button onClick={()=>{setSaved(s=>[...s,`PR-${s.length+1}`])}}>SAVE</button><button onClick={()=>setPrompt("")}>CLEAR</button></div></div><textarea value={prompt} onChange={e=>setPrompt(e.target.value)}/><div className="history"><b>PROMPT HISTORY</b>{saved.map(x=><span key={x}>{x} • saved now</span>)}</div></div></div></PageShell>
}

function ProfilePage({t,auth}:{t:TFn;auth:AuthUser}){
  return <PageShell t={t} title="OPERATOR PROFILE" sub="Identity, role permissions and session status"><div className="profileGrid"><div className="profileHero"><div className="profileAvatar">{auth.name.slice(0,2).toUpperCase()}</div><div><span>OPERATOR</span><h2>{auth.name}</h2><p>{auth.operatorId} • {auth.email}</p></div><Badge status="ONLINE"/></div><div className="profileCards"><div><span>ROLE</span><b>{auth.role}</b></div><div><span>TEAM</span><b>DISASTER RESPONSE</b></div><div><span>LANGUAGE</span><b>Interface Preference</b></div><div><span>SESSION</span><b>SECURE / DEMO</b></div></div><div className="permissionPanel"><h3>ROLE PERMISSIONS</h3>{[["Dashboard","Full monitoring"],["Live Map","View + track"],["Robots","Telemetry + messaging"],["ResQPath","Route recovery"],["Simulation","Run failure drills"],["Emergency Stop",auth.role==="Viewer"?"Restricted":"Operator action"]].map(([a,b])=><div key={a}><span>{a}</span><b>{b}</b></div>)}</div></div></PageShell>
}

function SettingsPage({t,language,setLanguage}:{t:TFn;language:Language;setLanguage:(v:Language)=>void}){
  return <PageShell t={t} title={t("settingsTitle")} sub={t("settingsSub")}><div className="settings"><div className="setting"><div><b>{t("language")}</b><span>{languages.find(l=>l.code===language)?.native}</span></div><LanguageSelector language={language} setLanguage={setLanguage}/></div>
    <Setting t={t} title={t("refresh")} value="1 second"/><Setting t={t} title={t("alertsSetting")} value={t("enabled")}/><Setting t={t} title={t("simMode")} value={t("demo")}/><Setting t={t} title={t("routing")} value={t("enabled")}/>
  </div></PageShell>
}
function Setting({t,title,value}:{t:TFn;title:string;value:string}){return <div className="setting"><div><b>{title}</b><span>{value}</span></div><button>{t("configure")}<ChevronRight size={15}/></button></div>}

createRoot(document.getElementById("root")!).render(<React.StrictMode><App/></React.StrictMode>);
