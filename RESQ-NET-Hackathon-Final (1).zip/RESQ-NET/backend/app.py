from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import sqlite3, math

app = Flask(__name__)
CORS(app)
DB = 'resq_net.db'

ROBOTS = [
 {'id':'R01','status':'ONLINE','battery':92,'signal':-42,'packetLoss':0.8,'latency':54,'position':'Zone A','communicationRange':120,'role':'Gateway'},
 {'id':'R02','status':'ONLINE','battery':81,'signal':-51,'packetLoss':1.1,'latency':63,'position':'Zone B','communicationRange':120,'role':'Relay'},
 {'id':'R03','status':'OFFLINE','battery':78,'signal':-61,'packetLoss':2.1,'latency':84,'position':'Zone B','communicationRange':120,'role':'Relay'},
 {'id':'R04','status':'WARNING','battery':34,'signal':-72,'packetLoss':3.4,'latency':110,'position':'Zone C','communicationRange':120,'role':'Explorer'},
 {'id':'R05','status':'ONLINE','battery':67,'signal':-55,'packetLoss':1.2,'latency':61,'position':'Zone D','communicationRange':120,'role':'Relay'},
 {'id':'R06','status':'OFFLINE','battery':18,'signal':None,'packetLoss':None,'latency':None,'position':'Zone E','communicationRange':120,'role':'Recon'},
]

@app.get('/api/health')
def health():
    return jsonify({'status':'ok','service':'RESQ-NET API','time':datetime.utcnow().isoformat()})

@app.post('/api/auth/login')
def login():
    body=request.get_json(silent=True) or {}
    return jsonify({'ok':True,'operator':body.get('operatorId','operator01'),'role':'Control Operator','demo':True})

@app.post('/api/auth/signup')
def signup():
    body=request.get_json(silent=True) or {}
    return jsonify({'ok':True,'message':'Prototype operator created','operatorId':body.get('operatorId')})

@app.post('/api/auth/logout')
def logout(): return jsonify({'ok':True})

@app.get('/api/robots')
def robots(): return jsonify(ROBOTS)

@app.get('/api/robots/<rid>')
def robot(rid):
    item=next((r for r in ROBOTS if r['id']==rid),None)
    return (jsonify(item),200) if item else (jsonify({'error':'Robot not found'}),404)

@app.get('/api/network')
def network():
    return jsonify({'health':92,'coverage':87,'activeRoutes':14,'links':[
        {'a':'R01','b':'R02','status':'healthy'},{'a':'R02','b':'R03','status':'weak'},
        {'a':'R03','b':'R04','status':'broken'},{'a':'R05','b':'R02','status':'healthy'}]})

@app.get('/api/routes')
def routes(): return jsonify([{'source':'R04','destination':'CONTROL','nodes':['R04','R03','R02','CONTROL'],'cost':4.8,'latency':84,'reliability':71,'status':'degraded'}])

@app.post('/api/routes/recalculate')
def recalculate(): return jsonify(recover_route())

@app.get('/api/messages')
def messages():
    return jsonify([{'id':'MSG-1024','sender':'R03','receiver':'CONTROL','priority':'CRITICAL','status':'DELIVERED','timestamp':datetime.utcnow().isoformat(),'route':['R03','R02','R01','CONTROL']}])

@app.post('/api/messages')
def create_message():
    body=request.get_json(silent=True) or {}
    return jsonify({'ok':True,'messageId':'MSG-NEW','status':'STORED' if body.get('offline') else 'DELIVERED'})

@app.get('/api/alerts')
def alerts(): return jsonify([{'id':'A-02','type':'VICTIM','severity':'CRITICAL','robot':'R03','location':'Zone B-14','status':'OPEN'}])

@app.get('/api/victims')
def victims(): return jsonify([{'id':'V-024','location':'Zone B-14','detectedBy':'R03','confidence':94,'timestamp':datetime.utcnow().isoformat(),'status':'UNRESCUED'}])

@app.get('/api/missions')
def missions(): return jsonify([{'id':'M-104','name':'Victim Search','targetZone':'B-14','priority':'CRITICAL','assignedRobots':['R03','R05'],'status':'IN PROGRESS','progress':68}])

@app.post('/api/missions')
def create_mission(): return jsonify({'ok':True,'missionId':'M-107'})

@app.get('/api/resqpath')
def resqpath(): return jsonify(recover_route())

@app.post('/api/resqpath/recover')
def resqpath_recover(): return jsonify(recover_route())

def score(r):
    # Higher is better; simulated prototype metric.
    battery=r['battery']/100
    rssi=max(0,(r['signal']+100)/60) if r['signal'] is not None else 0
    loss=max(0,1-(r['packetLoss'] or 100)/20)
    latency=max(0,1-(r['latency'] or 999)/300)
    distance=0.85
    return round(100*(0.25*battery+0.25*rssi+0.2*loss+0.2*latency+0.1*distance),1)

def recover_route():
    candidates=[r for r in ROBOTS if r['status']!='OFFLINE']
    ranked=sorted(candidates,key=score,reverse=True)
    relay=next((r for r in ranked if r['id'] in {'R05','R02','R04','R01'}),ranked[0])
    return {'failure':{'robot':'R03','reason':'Communication link unavailable','mission':'VICTIM-024'},
            'analysis':['Checking available relay robots','Analysing RSSI','Analysing packet loss','Calculating alternative routes','Selecting relay'],
            'recommendedRelay':relay,'route':['R04',relay['id'],'R02','CONTROL'],'routeReliability':96,'status':'RECOVERED','score':score(relay)}

@app.post('/api/simulation/link-failure')
def link_failure(): return jsonify(recover_route())

@app.post('/api/simulation/robot-failure')
def robot_failure(): return jsonify(recover_route())

@app.get('/api/analytics')
def analytics(): return jsonify({'deliveryRate':98.7,'avgLatency':61,'packetLoss':1.3,'coverage':87,'routeFailures':24,'routesRecovered':23,'recoveryRate':95.8,'avgRecoveryTime':2.4,'mostUsedRelay':'R05','storeForwardEvents':8})

@app.get('/api/settings')
def settings(): return jsonify({'language':'en','reducedMotion':False,'notifications':True,'sessionTimeout':30})

if __name__=='__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)
