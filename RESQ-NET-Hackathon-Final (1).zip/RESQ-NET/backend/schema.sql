CREATE TABLE IF NOT EXISTS operators (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  operator_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL,
  language TEXT DEFAULT 'en',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS robots (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  battery REAL NOT NULL,
  signal REAL,
  packet_loss REAL,
  latency REAL,
  position TEXT,
  communication_range REAL,
  role TEXT
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  sender TEXT,
  receiver TEXT,
  priority TEXT,
  status TEXT,
  timestamp TEXT,
  route TEXT
);
CREATE TABLE IF NOT EXISTS missions (
  id TEXT PRIMARY KEY,
  name TEXT,
  target_zone TEXT,
  priority TEXT,
  assigned_robots TEXT,
  status TEXT,
  progress REAL
);
