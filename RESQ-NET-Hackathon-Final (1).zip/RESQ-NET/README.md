# RESQ-NET — Resilient Communication Network

Hackathon-ready disaster-response robotics command center prototype.

## Source-aligned concept
The project brief describes the core problem as unreliable/offline disaster communication and requires reliable robot-to-robot communication under intermittent connectivity. The UI therefore demonstrates ad-hoc mesh, multi-hop communication, priority queuing, store-and-forward, dynamic routing, reliable delivery, link-quality monitoring and a control station.

## Frontend
- React + TypeScript + Vite
- Framer Motion
- Lucide icons
- Responsive cinematic command-center UI
- 13-language interface with persisted language preference and Arabic RTL
- Animated rescue robot scene
- Tactical disaster map with live-style overlays
- ResQPath route-recovery simulation
- Robot access panel + no-network SMS/store-and-forward flow
- Victim detection, missions, alerts, analytics, prompt generator and operator profile

## Demo flow
1. Splash / animated robot
2. Language selection
3. Login / Signup
4. Command Center
5. Live Tactical Map
6. Robot Fleet → select R03
7. Simulate no network → type message → message is stored
8. Restore network → forward/deliver
9. ResQPath → simulate R03 failure → R05 relay → recovered route
10. Victim Detection → dispatch
11. Analytics / Prompt Generator / Profile

## Run frontend
```bash
npm install
npm run dev
```

## Optional Flask API
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate   # Windows
pip install -r requirements.txt
python app.py
```

API: `http://localhost:5000/api`

The frontend works with demo/mock state even when the Flask API is not running. The API structure is ready for future WebSocket/PostgreSQL integration.

## Demo credentials
- operator01 / demo123 — Control Operator
- admin01 / demo123 — Admin
- rescue01 / demo123 — Rescue Team
- viewer01 / demo123 — Viewer

These are prototype/demo credentials only.
