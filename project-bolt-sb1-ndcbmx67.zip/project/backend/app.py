import os
import sqlite3
import json
from datetime import datetime
from flask import Flask, request, jsonify, g
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

DATABASE = os.path.join(os.path.dirname(__file__), 'resqnet.db')


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db


@app.teardown_appcontext
def close_db(error):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS robots (
        id TEXT PRIMARY KEY, name TEXT, role TEXT, status TEXT,
        battery REAL, rssi REAL, latency REAL, packet_loss REAL,
        zone TEXT, pos_x REAL, pos_y REAL, mission TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY, sender TEXT, receiver TEXT, priority TEXT,
        content TEXT, status TEXT, timestamp TEXT, relay_path TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS victims (
        id TEXT PRIMARY KEY, location TEXT, priority TEXT, confidence REAL,
        detected_by TEXT, status TEXT, detected_at TEXT, pos_x REAL, pos_y REAL
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS missions (
        id TEXT PRIMARY KEY, name TEXT, zone TEXT, robot TEXT, priority TEXT,
        status TEXT, progress REAL, victims TEXT, route TEXT, created_at TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS alerts (
        id TEXT PRIMARY KEY, severity TEXT, title TEXT, description TEXT,
        timestamp TEXT, acknowledged INTEGER
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS network_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, target TEXT,
        status TEXT, reliability REAL
    )''')

    seed_data(c)
    conn.commit()
    conn.close()


def seed_data(c):
    robots = [
        ('R01', 'Sentinel One', 'GATEWAY', 'ONLINE', 92, -42, 54, 0.8, 'ZONE A', 20, 30, 'RESCUE-204'),
        ('R02', 'Relay Alpha', 'RELAY', 'ONLINE', 81, -51, 63, 1.1, 'ZONE B', 45, 25, None),
        ('R03', 'Pathfinder', 'SCOUT', 'OFFLINE', 78, -61, 84, 2.1, 'ZONE C', 60, 55, 'RESCUE-204'),
        ('R04', 'Rescue Four', 'RESCUE', 'WARNING', 34, -72, 110, 3.4, 'ZONE C', 70, 70, 'RESCUE-204'),
        ('R05', 'Relay Bravo', 'RELAY', 'ONLINE', 67, -55, 61, 1.2, 'ZONE D', 35, 65, None),
        ('R06', 'Guardian', 'GUARDIAN', 'OFFLINE', 18, -80, 0, 100, 'ZONE E', 85, 40, None),
    ]
    c.executemany('''INSERT OR REPLACE INTO robots VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''', robots)

    messages = [
        ('M001', 'R03', 'CONTROL', 'CRITICAL', 'Victim detected near Zone C.', 'WAITING', '14:38:22', json.dumps(['R03','R05','R02','CONTROL'])),
        ('M002', 'R01', 'CONTROL', 'HIGH', 'Gateway link stable.', 'DELIVERED', '14:35:10', None),
        ('M003', 'R04', 'CONTROL', 'CRITICAL', 'Battery critical at 34%.', 'WAITING', '14:40:05', json.dumps(['R04','R05','R01','CONTROL'])),
        ('M004', 'R05', 'R02', 'MEDIUM', 'Relay handoff complete.', 'DELIVERED', '14:32:41', None),
        ('M005', 'R02', 'CONTROL', 'MEDIUM', 'Mission update: RESCUE-204 at 65%.', 'DELIVERED', '14:30:15', None),
        ('M006', 'R06', 'CONTROL', 'LOW', 'Telemetry update.', 'FAILED', '14:20:00', None),
    ]
    c.executemany('''INSERT OR REPLACE INTO messages VALUES (?,?,?,?,?,?,?,?)''', messages)

    victims = [
        ('V-101', 'ZONE A / SECTOR 3', 'MEDIUM', 87, 'R01', 'RESCUED', '13:45:22', 22, 35),
        ('V-102', 'ZONE C / SECTOR 7', 'CRITICAL', 94, 'R03', 'AWAITING_RESCUE', '14:38:22', 62, 58),
        ('V-103', 'ZONE C / SECTOR 9', 'CRITICAL', 91, 'R03', 'IN_RESCUE', '14:35:10', 68, 72),
        ('V-104', 'ZONE B / SECTOR 1', 'HIGH', 79, 'R02', 'AWAITING_RESCUE', '14:20:45', 47, 28),
        ('V-105', 'ZONE D / SECTOR 4', 'MEDIUM', 82, 'R05', 'AWAITING_RESCUE', '14:15:30', 37, 68),
        ('V-106', 'ZONE C / SECTOR 12', 'HIGH', 88, 'R04', 'IN_RESCUE', '14:10:15', 72, 65),
    ]
    c.executemany('''INSERT OR REPLACE INTO victims VALUES (?,?,?,?,?,?,?,?,?)''', victims)

    missions = [
        ('RESCUE-204', 'Zone C Victim Extraction', 'ZONE C', 'R04', 'HIGH', 'ACTIVE', 65, json.dumps(['V-102','V-103','V-106']), json.dumps(['CONTROL','R01','R05','R04']), '13:30:00'),
        ('RESCUE-205', 'Zone B Perimeter Sweep', 'ZONE B', 'R02', 'MEDIUM', 'ACTIVE', 40, json.dumps(['V-104']), json.dumps(['CONTROL','R01','R02']), '14:00:00'),
        ('RESCUE-206', 'Zone D Reconnaissance', 'ZONE D', 'R05', 'LOW', 'ACTIVE', 78, json.dumps(['V-105']), json.dumps(['CONTROL','R01','R05']), '12:45:00'),
        ('RESCUE-207', 'Zone E Recovery', 'ZONE E', 'R06', 'CRITICAL', 'PLANNED', 0, json.dumps([]), json.dumps(['CONTROL','R01','R05','R04','R06']), '14:42:00'),
        ('RESCUE-203', 'Zone A Cleanup', 'ZONE A', 'R01', 'LOW', 'COMPLETED', 100, json.dumps(['V-101']), json.dumps(['CONTROL','R01']), '12:00:00'),
    ]
    c.executemany('''INSERT OR REPLACE INTO missions VALUES (?,?,?,?,?,?,?,?,?,?)''', missions)

    alerts = [
        ('A001', 'CRITICAL', 'R03 OFFLINE', 'Pathfinder lost communication.', '14:38:00', 0),
        ('A002', 'CRITICAL', 'Victim detected — Zone C', 'V-102 detected by R03. Confidence 94%.', '14:38:22', 0),
        ('A003', 'WARNING', 'Network link degraded', 'R05-R04 link reliability at 68%.', '14:36:10', 0),
        ('A004', 'SUCCESS', 'Route recovered', 'R02-R05-R04 path established.', '14:35:00', 1),
        ('A005', 'HIGH', 'R04 battery critical', 'Rescue Four battery at 34%.', '14:40:05', 0),
        ('A006', 'CRITICAL', 'R06 OFFLINE', 'Guardian battery exhausted.', '14:20:00', 1),
    ]
    c.executemany('''INSERT OR REPLACE INTO alerts VALUES (?,?,?,?,?,?)''', alerts)

    links = [
        (None, 'CONTROL', 'R01', 'ONLINE', 99),
        (None, 'R01', 'R02', 'ONLINE', 97),
        (None, 'R01', 'R05', 'ONLINE', 95),
        (None, 'R02', 'R03', 'FAILED', 0),
        (None, 'R02', 'R05', 'ONLINE', 92),
        (None, 'R05', 'R04', 'WEAK', 68),
        (None, 'R03', 'R04', 'FAILED', 0),
        (None, 'R04', 'R06', 'FAILED', 0),
    ]
    c.executemany('''INSERT OR REPLACE INTO network_links (id, source, target, status, reliability) VALUES (?,?,?,?,?)''', links)


def row_to_dict(row):
    return {k: row[k] for k in row.keys()}


# ============ HEALTH ============
@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'service': 'RESQ-NET', 'timestamp': datetime.now().isoformat()})


# ============ AUTH ============
@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username', '')
    password = data.get('password', '')
    users = {
        'operator01': {'role': 'OPERATOR', 'name': 'Cmdr. Sarah Chen', 'access': 'LEVEL 4 — FULL OPERATIONS', 'region': 'SECTOR NORTH'},
        'admin01': {'role': 'ADMIN', 'name': 'Director Marcus Hale', 'access': 'LEVEL 5 — ADMINISTRATOR', 'region': 'ALL SECTORS'},
        'rescue01': {'role': 'RESCUE', 'name': 'Sgt. Elena Vasquez', 'access': 'LEVEL 3 — FIELD OPERATIONS', 'region': 'ZONE C'},
        'viewer01': {'role': 'VIEWER', 'name': 'Observer James Lee', 'access': 'LEVEL 1 — READ ONLY', 'region': 'OBSERVER'},
    }
    if username in users and password == 'demo123':
        return jsonify({'success': True, 'user': {**users[username], 'username': username}})
    return jsonify({'success': False, 'error': 'Invalid credentials'}), 401


@app.route('/api/auth/signup', methods=['POST'])
def signup():
    data = request.json or {}
    return jsonify({'success': True, 'user': {'username': data.get('username',''), 'role': 'OPERATOR', 'name': data.get('username','')}})


@app.route('/api/auth/logout', methods=['POST'])
def logout():
    return jsonify({'success': True})


# ============ ROBOTS ============
@app.route('/api/robots')
def get_robots():
    db = get_db()
    rows = db.execute('SELECT * FROM robots').fetchall()
    result = []
    for r in rows:
        d = row_to_dict(r)
        d['position'] = {'x': d.pop('pos_x'), 'y': d.pop('pos_y')}
        result.append(d)
    return jsonify(result)


@app.route('/api/robots/<robot_id>')
def get_robot(robot_id):
    db = get_db()
    r = db.execute('SELECT * FROM robots WHERE id = ?', (robot_id,)).fetchone()
    if not r:
        return jsonify({'error': 'Robot not found'}), 404
    d = row_to_dict(r)
    d['position'] = {'x': d.pop('pos_x'), 'y': d.pop('pos_y')}
    return jsonify(d)


# ============ NETWORK ============
@app.route('/api/network')
def get_network():
    db = get_db()
    links = db.execute('SELECT * FROM network_links').fetchall()
    return jsonify([{'from': r['source'], 'to': r['target'], 'status': r['status'], 'reliability': r['reliability']} for r in links])


# ============ ROUTES ============
@app.route('/api/routes')
def get_routes():
    db = get_db()
    robots = db.execute('SELECT id, status, battery, rssi, latency, packet_loss FROM robots WHERE status = "ONLINE"').fetchall()
    return jsonify([row_to_dict(r) for r in robots])


@app.route('/api/routes/recalculate', methods=['POST'])
def recalculate_routes():
    db = get_db()
    online = db.execute('SELECT id, battery, rssi, latency, packet_loss FROM robots WHERE status = "ONLINE" ORDER BY battery DESC, rssi DESC').fetchall()
    route = [r['id'] for r in online]
    return jsonify({'status': 'recalculated', 'route': route, 'reliability': 94})


# ============ MESSAGES ============
@app.route('/api/messages')
def get_messages():
    db = get_db()
    rows = db.execute('SELECT * FROM messages ORDER BY timestamp DESC').fetchall()
    result = []
    for r in rows:
        d = row_to_dict(r)
        if d.get('relay_path'):
            d['relayPath'] = json.loads(d['relay_path'])
        del d['relay_path']
        result.append(d)
    return jsonify(result)


@app.route('/api/messages', methods=['POST'])
def create_message():
    data = request.json or {}
    db = get_db()
    msg_id = f"M{db.execute('SELECT COUNT(*) FROM messages').fetchone()[0] + 1:03d}"
    db.execute(
        'INSERT INTO messages (id, sender, receiver, priority, content, status, timestamp, relay_path) VALUES (?,?,?,?,?,?,?,?)',
        (msg_id, data.get('sender',''), data.get('receiver','CONTROL'), data.get('priority','MEDIUM'),
         data.get('content',''), 'WAITING', datetime.now().strftime('%H:%M:%S'),
         json.dumps(data.get('relayPath', [])))
    )
    db.commit()
    return jsonify({'success': True, 'id': msg_id})


# ============ ALERTS ============
@app.route('/api/alerts')
def get_alerts():
    db = get_db()
    rows = db.execute('SELECT * FROM alerts ORDER BY timestamp DESC').fetchall()
    return jsonify([row_to_dict(r) for r in rows])


# ============ VICTIMS ============
@app.route('/api/victims')
def get_victims():
    db = get_db()
    rows = db.execute('SELECT * FROM victims').fetchall()
    result = []
    for r in rows:
        d = row_to_dict(r)
        d['position'] = {'x': d.pop('pos_x'), 'y': d.pop('pos_y')}
        d['detectedBy'] = d.pop('detected_by')
        d['detectedAt'] = d.pop('detected_at')
        result.append(d)
    return jsonify(result)


# ============ MISSIONS ============
@app.route('/api/missions')
def get_missions():
    db = get_db()
    rows = db.execute('SELECT * FROM missions').fetchall()
    result = []
    for r in rows:
        d = row_to_dict(r)
        d['victims'] = json.loads(d['victims']) if d['victims'] else []
        d['route'] = json.loads(d['route']) if d['route'] else []
        d['createdAt'] = d.pop('created_at')
        result.append(d)
    return jsonify(result)


@app.route('/api/missions', methods=['POST'])
def create_mission():
    data = request.json or {}
    db = get_db()
    mid = f"RESCUE-{db.execute('SELECT COUNT(*) FROM missions').fetchone()[0] + 208}"
    db.execute(
        'INSERT INTO missions (id, name, zone, robot, priority, status, progress, victims, route, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
        (mid, data.get('name',''), data.get('zone',''), data.get('robot',''),
         data.get('priority','MEDIUM'), 'PLANNED', 0, '[]', '[]', datetime.now().strftime('%H:%M:%S'))
    )
    db.commit()
    return jsonify({'success': True, 'id': mid})


# ============ RESQPATH ============
@app.route('/api/resqpath')
def get_resqpath():
    db = get_db()
    online = db.execute('SELECT id, battery, rssi, latency, packet_loss FROM robots WHERE status = "ONLINE"').fetchall()
    failed = db.execute('SELECT id FROM robots WHERE status != "ONLINE"').fetchall()
    return jsonify({
        'onlineRobots': [r['id'] for r in online],
        'failedRobots': [r['id'] for r in failed],
        'currentRoute': ['CONTROL', 'R01', 'R05', 'R04'],
    })


@app.route('/api/resqpath/recover', methods=['POST'])
def recover_resqpath():
    db = get_db()
    online = db.execute('SELECT id, battery, rssi, latency, packet_loss FROM robots WHERE status = "ONLINE" ORDER BY (battery + (100 + rssi) * 0.5) DESC').fetchall()
    if len(online) >= 2:
        relay = online[0]['id']
        route = [r['id'] for r in online[:3]]
        reliability = int(sum(r['battery'] for r in online[:3]) / 3)
    else:
        relay = 'NONE'
        route = []
        reliability = 0
    return jsonify({
        'status': 'recovered' if route else 'failed',
        'failure': 'R03 offline',
        'recommendedRelay': relay,
        'route': route,
        'reliability': min(reliability, 99),
    })


# ============ SIMULATION ============
@app.route('/api/simulation/link-failure', methods=['POST'])
def sim_link_failure():
    return jsonify({
        'status': 'recovered', 'failure': 'R02 → R03 link down',
        'recommendedRelay': 'R05', 'route': ['R02', 'R05', 'R04'], 'reliability': 94,
    })


@app.route('/api/simulation/robot-failure', methods=['POST'])
def sim_robot_failure():
    return jsonify({
        'status': 'recovered', 'failure': 'R03 offline',
        'recommendedRelay': 'R05', 'route': ['R02', 'R05', 'R04'], 'reliability': 91,
    })


# ============ ANALYTICS ============
@app.route('/api/analytics')
def get_analytics():
    db = get_db()
    total = db.execute('SELECT COUNT(*) FROM robots').fetchone()[0]
    online = db.execute('SELECT COUNT(*) FROM robots WHERE status = "ONLINE"').fetchone()[0]
    avg_batt = db.execute('SELECT AVG(battery) FROM robots').fetchone()[0] or 0
    return jsonify({
        'networkReliability': 94.2,
        'packetLoss': 1.4,
        'avgLatency': 71,
        'robotAvailability': round(online / total * 100, 1) if total else 0,
        'messageDelivery': 92.8,
        'routeRecovery': 97.5,
        'batteryHealth': round(avg_batt, 1),
    })


# ============ SETTINGS ============
@app.route('/api/settings')
def get_settings():
    return jsonify({
        'language': 'en',
        'notifications': True,
        'simulationMode': True,
        'highContrast': False,
        'reducedMotion': False,
    })


if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
