import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import type { User, UserRole } from '@/types'
import { users } from '@/data/mockData'

interface AuthContextValue {
  user: User | null
  login: (username: string, password: string) => { success: boolean; error?: string }
  signup: (username: string, password: string) => { success: boolean; error?: string }
  logout: () => void
  canAccess: (page: string) => boolean
  accessiblePages: string[]
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

const STORAGE_KEY = 'resq-user'

import { roleAccess } from '@/data/mockData'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        try { return JSON.parse(stored) as User } catch { return null }
      }
    }
    return null
  })

  const login = useCallback((username: string, password: string): { success: boolean; error?: string } => {
    const knownUser = users[username]
    if (knownUser && password === 'demo123') {
      setUser(knownUser)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(knownUser))
      return { success: true }
    }
    if (knownUser && password !== 'demo123') {
      return { success: false, error: 'Invalid credentials' }
    }
    const stored = localStorage.getItem(`resq-account-${username}`)
    if (stored && stored === password) {
      const newUser: User = {
        username,
        role: 'OPERATOR',
        name: username,
        accessLevel: 'LEVEL 4 — FULL OPERATIONS',
        lastActivity: new Date().toLocaleTimeString('en-GB'),
        region: 'SECTOR NORTH',
      }
      setUser(newUser)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser))
      return { success: true }
    }
    return { success: false, error: 'Account not found. Use demo credentials or sign up.' }
  }, [])

  const signup = useCallback((username: string, password: string): { success: boolean; error?: string } => {
    if (!username || !password) return { success: false, error: 'Username and password required' }
    if (users[username]) return { success: false, error: 'Username already exists' }
    localStorage.setItem(`resq-account-${username}`, password)
    const newUser: User = {
      username,
      role: 'OPERATOR',
      name: username,
      accessLevel: 'LEVEL 4 — FULL OPERATIONS',
      lastActivity: new Date().toLocaleTimeString('en-GB'),
      region: 'SECTOR NORTH',
    }
    setUser(newUser)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser))
    return { success: true }
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    localStorage.removeItem(STORAGE_KEY)
  }, [])

  const canAccess = useCallback((page: string): boolean => {
    if (!user) return false
    return roleAccess[user.role].includes(page)
  }, [user])

  const accessiblePages = user ? roleAccess[user.role] : []

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, canAccess, accessiblePages }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
