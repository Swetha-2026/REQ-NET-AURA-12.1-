import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react'
import { translations, languages, type LanguageCode } from '@/data/translations'

interface LanguageContextValue {
  lang: LanguageCode
  setLang: (code: LanguageCode) => void
  t: (key: string) => string
  isRTL: boolean
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined)

const STORAGE_KEY = 'resq-language'

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(STORAGE_KEY) as LanguageCode | null
      if (stored && translations[stored]) return stored
    }
    return 'en'
  })

  const isRTL = lang === 'ar'

  const setLang = useCallback((code: LanguageCode) => {
    setLangState(code)
    localStorage.setItem(STORAGE_KEY, code)
  }, [])

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr'
    document.documentElement.lang = lang
  }, [lang, isRTL])

  const t = useCallback((key: string): string => {
    return translations[lang]?.[key] ?? translations.en[key] ?? key
  }, [lang])

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const ctx = useContext(LanguageContext)
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider')
  return ctx
}

export { languages }
