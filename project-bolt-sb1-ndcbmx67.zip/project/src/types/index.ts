export type RobotStatus = 'ONLINE' | 'WARNING' | 'OFFLINE'
export type RobotRole = 'GATEWAY' | 'RELAY' | 'SCOUT' | 'RESCUE' | 'GUARDIAN'

export interface Robot {
  id: string
  name: string
  role: RobotRole
  status: RobotStatus
  battery: number
  rssi: number
  latency: number
  packetLoss: number
  zone: string
  position: { x: number; y: number }
  mission?: string
}

export type MessagePriority = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'
export type MessageStatus = 'DELIVERED' | 'WAITING' | 'QUEUED' | 'FAILED'

export interface Message {
  id: string
  sender: string
  receiver: string
  priority: MessagePriority
  content: string
  status: MessageStatus
  timestamp: string
  relayPath?: string[]
}

export type VictimPriority = 'CRITICAL' | 'HIGH' | 'MEDIUM'
export type VictimStatus = 'AWAITING_RESCUE' | 'IN_RESCUE' | 'RESCUED' | 'DECEASED'

export interface Victim {
  id: string
  location: string
  priority: VictimPriority
  confidence: number
  detectedBy: string
  status: VictimStatus
  detectedAt: string
  position: { x: number; y: number }
}

export type MissionPriority = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'
export type MissionStatus = 'ACTIVE' | 'PLANNED' | 'COMPLETED' | 'ABORTED'

export interface Mission {
  id: string
  name: string
  zone: string
  robot: string
  priority: MissionPriority
  status: MissionStatus
  progress: number
  victims: string[]
  route: string[]
  createdAt: string
}

export type AlertSeverity = 'CRITICAL' | 'HIGH' | 'WARNING' | 'SUCCESS'

export interface Alert {
  id: string
  severity: AlertSeverity
  title: string
  description: string
  timestamp: string
  acknowledged: boolean
}

export type UserRole = 'ADMIN' | 'OPERATOR' | 'RESCUE' | 'VIEWER'

export interface User {
  username: string
  role: UserRole
  name: string
  activeMission?: string
  accessLevel: string
  lastActivity: string
  region: string
}

export interface NetworkLink {
  from: string
  to: string
  status: 'ONLINE' | 'WEAK' | 'FAILED'
  reliability: number
}

export interface AnalyticsData {
  networkReliability: number
  packetLoss: number
  avgLatency: number
  robotAvailability: number
  messageDelivery: number
  routeRecovery: number
  batteryHealth: number
  reliabilityHistory: number[]
  latencyHistory: number[]
  packetLossHistory: number[]
}

export interface ResQPathResult {
  status: 'recovered' | 'analyzing' | 'failed'
  failure: string
  recommendedRelay: string
  route: string[]
  reliability: number
  steps: string[]
}
