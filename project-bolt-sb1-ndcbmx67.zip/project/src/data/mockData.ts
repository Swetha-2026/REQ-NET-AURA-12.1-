import type { Robot, Message, Victim, Mission, Alert, NetworkLink, AnalyticsData, User } from '@/types'

export const robots: Robot[] = [
  { id: 'R01', name: 'Sentinel One', role: 'GATEWAY', status: 'ONLINE', battery: 92, rssi: -42, latency: 54, packetLoss: 0.8, zone: 'ZONE A', position: { x: 20, y: 30 }, mission: 'RESCUE-204' },
  { id: 'R02', name: 'Relay Alpha', role: 'RELAY', status: 'ONLINE', battery: 81, rssi: -51, latency: 63, packetLoss: 1.1, zone: 'ZONE B', position: { x: 45, y: 25 } },
  { id: 'R03', name: 'Pathfinder', role: 'SCOUT', status: 'OFFLINE', battery: 78, rssi: -61, latency: 84, packetLoss: 2.1, zone: 'ZONE C', position: { x: 60, y: 55 }, mission: 'RESCUE-204' },
  { id: 'R04', name: 'Rescue Four', role: 'RESCUE', status: 'WARNING', battery: 34, rssi: -72, latency: 110, packetLoss: 3.4, zone: 'ZONE C', position: { x: 70, y: 70 }, mission: 'RESCUE-204' },
  { id: 'R05', name: 'Relay Bravo', role: 'RELAY', status: 'ONLINE', battery: 67, rssi: -55, latency: 61, packetLoss: 1.2, zone: 'ZONE D', position: { x: 35, y: 65 } },
  { id: 'R06', name: 'Guardian', role: 'GUARDIAN', status: 'OFFLINE', battery: 18, rssi: -80, latency: 0, packetLoss: 100, zone: 'ZONE E', position: { x: 85, y: 40 } },
]

export const networkLinks: NetworkLink[] = [
  { from: 'CONTROL', to: 'R01', status: 'ONLINE', reliability: 99 },
  { from: 'R01', to: 'R02', status: 'ONLINE', reliability: 97 },
  { from: 'R01', to: 'R05', status: 'ONLINE', reliability: 95 },
  { from: 'R02', to: 'R03', status: 'FAILED', reliability: 0 },
  { from: 'R02', to: 'R05', status: 'ONLINE', reliability: 92 },
  { from: 'R05', to: 'R04', status: 'WEAK', reliability: 68 },
  { from: 'R03', to: 'R04', status: 'FAILED', reliability: 0 },
  { from: 'R04', to: 'R06', status: 'FAILED', reliability: 0 },
]

export const messages: Message[] = [
  { id: 'M001', sender: 'R03', receiver: 'CONTROL', priority: 'CRITICAL', content: 'Victim detected near Zone C. Requesting immediate rescue team dispatch.', status: 'WAITING', timestamp: '14:38:22', relayPath: ['R03', 'R05', 'R02', 'CONTROL'] },
  { id: 'M002', sender: 'R01', receiver: 'CONTROL', priority: 'HIGH', content: 'Gateway link stable. All telemetry packets nominal.', status: 'DELIVERED', timestamp: '14:35:10' },
  { id: 'M003', sender: 'R04', receiver: 'CONTROL', priority: 'CRITICAL', content: 'Battery critical at 34%. Requesting route reassignment to nearest relay.', status: 'WAITING', timestamp: '14:40:05', relayPath: ['R04', 'R05', 'R01', 'CONTROL'] },
  { id: 'M004', sender: 'R05', receiver: 'R02', priority: 'MEDIUM', content: 'Relay handoff complete. Path quality 92%.', status: 'DELIVERED', timestamp: '14:32:41' },
  { id: 'M005', sender: 'R02', receiver: 'CONTROL', priority: 'MEDIUM', content: 'Mission update: RESCUE-204 progress at 65%. Zone C perimeter secured.', status: 'DELIVERED', timestamp: '14:30:15' },
  { id: 'M006', sender: 'R06', receiver: 'CONTROL', priority: 'LOW', content: 'Telemetry update: Temperature 42C, humidity 68%.', status: 'FAILED', timestamp: '14:20:00' },
  { id: 'M007', sender: 'R04', receiver: 'R05', priority: 'HIGH', content: 'Store-and-forward buffer at 78%. Awaiting relay window.', status: 'QUEUED', timestamp: '14:41:30' },
]

export const victims: Victim[] = [
  { id: 'V-101', location: 'ZONE A / SECTOR 3', priority: 'MEDIUM', confidence: 87, detectedBy: 'R01', status: 'RESCUED', detectedAt: '13:45:22', position: { x: 22, y: 35 } },
  { id: 'V-102', location: 'ZONE C / SECTOR 7', priority: 'CRITICAL', confidence: 94, detectedBy: 'R03', status: 'AWAITING_RESCUE', detectedAt: '14:38:22', position: { x: 62, y: 58 } },
  { id: 'V-103', location: 'ZONE C / SECTOR 9', priority: 'CRITICAL', confidence: 91, detectedBy: 'R03', status: 'IN_RESCUE', detectedAt: '14:35:10', position: { x: 68, y: 72 } },
  { id: 'V-104', location: 'ZONE B / SECTOR 1', priority: 'HIGH', confidence: 79, detectedBy: 'R02', status: 'AWAITING_RESCUE', detectedAt: '14:20:45', position: { x: 47, y: 28 } },
  { id: 'V-105', location: 'ZONE D / SECTOR 4', priority: 'MEDIUM', confidence: 82, detectedBy: 'R05', status: 'AWAITING_RESCUE', detectedAt: '14:15:30', position: { x: 37, y: 68 } },
  { id: 'V-106', location: 'ZONE C / SECTOR 12', priority: 'HIGH', confidence: 88, detectedBy: 'R04', status: 'IN_RESCUE', detectedAt: '14:10:15', position: { x: 72, y: 65 } },
]

export const missions: Mission[] = [
  { id: 'RESCUE-204', name: 'Zone C Victim Extraction', zone: 'ZONE C', robot: 'R04', priority: 'HIGH', status: 'ACTIVE', progress: 65, victims: ['V-102', 'V-103', 'V-106'], route: ['CONTROL', 'R01', 'R05', 'R04'], createdAt: '13:30:00' },
  { id: 'RESCUE-205', name: 'Zone B Perimeter Sweep', zone: 'ZONE B', robot: 'R02', priority: 'MEDIUM', status: 'ACTIVE', progress: 40, victims: ['V-104'], route: ['CONTROL', 'R01', 'R02'], createdAt: '14:00:00' },
  { id: 'RESCUE-206', name: 'Zone D Reconnaissance', zone: 'ZONE D', robot: 'R05', priority: 'LOW', status: 'ACTIVE', progress: 78, victims: ['V-105'], route: ['CONTROL', 'R01', 'R05'], createdAt: '12:45:00' },
  { id: 'RESCUE-207', name: 'Zone E Recovery', zone: 'ZONE E', robot: 'R06', priority: 'CRITICAL', status: 'PLANNED', progress: 0, victims: [], route: ['CONTROL', 'R01', 'R05', 'R04', 'R06'], createdAt: '14:42:00' },
  { id: 'RESCUE-203', name: 'Zone A Cleanup', zone: 'ZONE A', robot: 'R01', priority: 'LOW', status: 'COMPLETED', progress: 100, victims: ['V-101'], route: ['CONTROL', 'R01'], createdAt: '12:00:00' },
]

export const alerts: Alert[] = [
  { id: 'A001', severity: 'CRITICAL', title: 'R03 OFFLINE', description: 'Pathfinder lost communication. ResQPath initiating route recovery.', timestamp: '14:38:00', acknowledged: false },
  { id: 'A002', severity: 'CRITICAL', title: 'Victim detected — Zone C', description: 'V-102 detected by R03. Confidence 94%. Awaiting rescue dispatch.', timestamp: '14:38:22', acknowledged: false },
  { id: 'A003', severity: 'WARNING', title: 'Network link degraded', description: 'R05 → R04 link reliability at 68%. Packet loss 3.4%.', timestamp: '14:36:10', acknowledged: false },
  { id: 'A004', severity: 'SUCCESS', title: 'Route recovered', description: 'R02 → R05 → R04 path established. Reliability 94%.', timestamp: '14:35:00', acknowledged: true },
  { id: 'A005', severity: 'HIGH', title: 'R04 battery critical', description: 'Rescue Four battery at 34%. Recommend immediate relay reassignment.', timestamp: '14:40:05', acknowledged: false },
  { id: 'A006', severity: 'CRITICAL', title: 'R06 OFFLINE', description: 'Guardian battery exhausted. Robot non-operational.', timestamp: '14:20:00', acknowledged: true },
]

export const analytics: AnalyticsData = {
  networkReliability: 94.2,
  packetLoss: 1.4,
  avgLatency: 71,
  robotAvailability: 66.7,
  messageDelivery: 92.8,
  routeRecovery: 97.5,
  batteryHealth: 61.7,
  reliabilityHistory: [88, 91, 89, 93, 95, 92, 94, 96, 93, 94, 95, 94],
  latencyHistory: [85, 78, 82, 70, 68, 72, 65, 60, 68, 71, 69, 71],
  packetLossHistory: [2.1, 1.8, 2.0, 1.5, 1.2, 1.4, 1.1, 0.9, 1.3, 1.4, 1.2, 1.4],
}

export const users: Record<string, User> = {
  operator01: { username: 'operator01', role: 'OPERATOR', name: 'Cmdr. Sarah Chen', activeMission: 'RESCUE-204', accessLevel: 'LEVEL 4 — FULL OPERATIONS', lastActivity: '14:42:08', region: 'SECTOR NORTH' },
  admin01: { username: 'admin01', role: 'ADMIN', name: 'Director Marcus Hale', activeMission: 'RESCUE-207', accessLevel: 'LEVEL 5 — ADMINISTRATOR', lastActivity: '14:42:08', region: 'ALL SECTORS' },
  rescue01: { username: 'rescue01', role: 'RESCUE', name: 'Sgt. Elena Vasquez', activeMission: 'RESCUE-204', accessLevel: 'LEVEL 3 — FIELD OPERATIONS', lastActivity: '14:41:50', region: 'ZONE C' },
  viewer01: { username: 'viewer01', role: 'VIEWER', name: 'Observer James Lee', accessLevel: 'LEVEL 1 — READ ONLY', lastActivity: '14:42:08', region: 'OBSERVER' },
}

export const robotImages: Record<string, string> = {
  R01: 'https://images.pexels.com/photos/8294549/pexels-photo-8294549.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  R02: 'https://images.pexels.com/photos/8294565/pexels-photo-8294565.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  R03: 'https://images.pexels.com/photos/35280158/pexels-photo-35280158.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  R04: 'https://images.pexels.com/photos/8438863/pexels-photo-8438863.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  R05: 'https://images.pexels.com/photos/34222354/pexels-photo-34222354.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  R06: 'https://images.pexels.com/photos/8294563/pexels-photo-8294563.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
}

export const heroRobotImage = 'https://images.pexels.com/photos/35280158/pexels-photo-35280158.jpeg?auto=compress&cs=tinysrgb&h=1200&w=900'

export const disasterImages = {
  rubble: 'https://images.pexels.com/photos/16105750/pexels-photo-16105750.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  aerial: 'https://images.pexels.com/photos/11511587/pexels-photo-11511587.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  earthquake: 'https://images.pexels.com/photos/15861718/pexels-photo-15861718.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
}

export const roleAccess: Record<UserRole, string[]> = {
  ADMIN: ['COMMAND', 'MAP', 'ROBOTS', 'NETWORK', 'RESQPATH', 'MESSAGES', 'ALERTS', 'VICTIMS', 'MISSIONS', 'SIMULATION', 'ANALYTICS', 'PROFILE', 'SETTINGS'],
  OPERATOR: ['COMMAND', 'MAP', 'ROBOTS', 'NETWORK', 'RESQPATH', 'MESSAGES', 'ALERTS', 'VICTIMS', 'MISSIONS', 'SIMULATION', 'ANALYTICS', 'PROFILE', 'SETTINGS'],
  RESCUE: ['COMMAND', 'MAP', 'ROBOTS', 'MESSAGES', 'VICTIMS', 'MISSIONS', 'PROFILE', 'SETTINGS'],
  VIEWER: ['COMMAND', 'MAP', 'ROBOTS', 'NETWORK', 'RESQPATH', 'MESSAGES', 'ALERTS', 'VICTIMS', 'MISSIONS', 'ANALYTICS', 'PROFILE', 'SETTINGS'],
}

export const demoCredentials = [
  { username: 'operator01', password: 'demo123', role: 'Control Operator' },
  { username: 'admin01', password: 'demo123', role: 'Admin' },
  { username: 'rescue01', password: 'demo123', role: 'Rescue Team' },
  { username: 'viewer01', password: 'demo123', role: 'Viewer' },
]
