import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Link2, Bot, Zap, Wifi, Radio, Play, Check, AlertTriangle,
  Activity, ArrowRight
} from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

type SimType = 'link' | 'robot' | 'packet' | 'rssi' | 'relay'

interface SimState {
  type: SimType | null
  step: number
  result: { failure: string; relay: string; route: string[]; reliability: number } | null
}

export default function SimulationPage() {
  const { t } = useLanguage()
  const [sim, setSim] = useState<SimState>({ type: null, step: -1, result: null })
  const [running, setRunning] = useState(false)

  const simButtons: { type: SimType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { type: 'link', label: t('simulateLinkFailure'), icon: Link2 },
    { type: 'robot', label: t('simulateRobotFailure'), icon: Bot },
    { type: 'packet', label: t('simulateHighPacketLoss'), icon: Zap },
    { type: 'rssi', label: t('simulateLowRSSI'), icon: Wifi },
    { type: 'relay', label: t('simulateRelayFailure'), icon: Radio },
  ]

  const simResults: Record<SimType, { failure: string; relay: string; route: string[]; reliability: number }> = {
    link: { failure: 'R02 → R03 link down', relay: 'R05', route: ['R02', 'R05', 'R04'], reliability: 94 },
    robot: { failure: 'R03 offline', relay: 'R05', route: ['R02', 'R05', 'R04'], reliability: 91 },
    packet: { failure: 'R04 packet loss 8.2%', relay: 'R05', route: ['R02', 'R05'], reliability: 88 },
    rssi: { failure: 'R04 RSSI -85dBm', relay: 'R05', route: ['R02', 'R05', 'R04'], reliability: 85 },
    relay: { failure: 'R02 relay down', relay: 'R05', route: ['R01', 'R05', 'R04'], reliability: 89 },
  }

  const steps = [t('failureDetected'), t('networkAnalysis'), t('alternativeRelay'), t('newRoute'), t('recovered')]

  const runSim = (type: SimType) => {
    setRunning(true)
    setSim({ type, step: 0, result: null })
    let current = 0
    const timer = setInterval(() => {
      current++
      if (current >= steps.length) {
        clearInterval(timer)
        setRunning(false)
        setSim({ type, step: current, result: simResults[type] })
      } else {
        setSim((prev) => ({ ...prev, step: current }))
      }
    }, 1000)
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('simulation')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">SCENARIO SIMULATION</h1>
      </div>

      {/* Sim buttons */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {simButtons.map((btn, idx) => (
          <motion.button
            key={btn.type}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.06 }}
            onClick={() => runSim(btn.type)}
            disabled={running}
            className="group glass rounded-lg p-4 text-left hover:border-accent/30 transition-all disabled:opacity-50 relative overflow-hidden"
          >
            <div className="flex items-start justify-between mb-2">
              <btn.icon className="w-5 h-5 text-accent" />
              <Play className="w-3.5 h-3.5 text-text-secondary group-hover:text-accent transition-colors" />
            </div>
            <p className="text-xs text-text-primary font-medium leading-tight">{btn.label}</p>
          </motion.button>
        ))}
      </div>

      {/* Simulation output */}
      <AnimatePresence>
        {sim.type && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-lg p-6 space-y-4"
          >
            <div className="flex items-center gap-2">
              <Activity className={`w-4 h-4 ${running ? 'text-accent animate-pulse' : 'text-success'}`} />
              <h3 className="font-display text-sm font-medium tracking-micro uppercase">
                {running ? t('recovering') : t('recovered')}
              </h3>
            </div>

            {/* Steps */}
            <div className="space-y-2.5">
              {steps.map((s, i) => {
                const isActive = sim.step >= i
                const isCurrent = sim.step === i && running
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0.3 }}
                    animate={{ opacity: isActive ? 1 : 0.3 }}
                    className="flex items-center gap-3"
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 border ${
                      isActive ? 'bg-accent/15 border-accent/40' : 'bg-white/5 border-white/10'
                    }`}>
                      {isActive && i < steps.length - 1 ? (
                        <Check className="w-3 h-3 text-accent" />
                      ) : isActive ? (
                        <Check className="w-3 h-3 text-success" />
                      ) : isCurrent ? (
                        <Activity className="w-3 h-3 text-accent animate-spin" />
                      ) : null}
                    </div>
                    <span className={`text-xs font-mono ${isActive ? 'text-text-primary' : 'text-text-secondary'}`}>{s}</span>
                  </motion.div>
                )
              })}
            </div>

            {/* Result */}
            {sim.result && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="pt-4 border-t border-white/10 space-y-3"
              >
                <div className="grid sm:grid-cols-2 gap-3">
                  <ResultRow label={t('failureDetected')} value={sim.result.failure} color="text-error" />
                  <ResultRow label={t('alternativeRelay')} value={sim.result.relay} color="text-accent" />
                  <ResultRow label={t('networkReliability')} value={`${sim.result.reliability}%`} color="text-success" />
                  <ResultRow label={t('status')} value={t('recovered')} color="text-success" />
                </div>
                <div>
                  <p className="text-[10px] tracking-micro text-text-secondary uppercase mb-2">{t('newRoute')}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {sim.result.route.map((node, i, arr) => (
                      <span key={i} className="flex items-center gap-2">
                        <span className={`px-3 py-1.5 rounded-md font-mono text-xs ${
                          i === 0 || i === arr.length - 1 ? 'bg-accent/15 text-accent border border-accent/30' : 'bg-white/5 text-text-primary border border-white/10'
                        }`}>{node}</span>
                        {i < arr.length - 1 && <ArrowRight className="w-3 h-3 text-text-secondary" />}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 bg-success/10 rounded-md">
                  <AlertTriangle className="w-3 h-3 text-success" />
                  <span className="text-[10px] tracking-micro text-success uppercase">{t('routeRestored')}</span>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function ResultRow({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-xs text-text-secondary">{label}</span>
      <span className={`font-mono text-xs ${color}`}>{value}</span>
    </div>
  )
}
