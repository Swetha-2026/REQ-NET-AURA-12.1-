import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, MessageSquare, Clock, AlertCircle, Check, X } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { messages as initialMessages } from '@/data/mockData'
import type { Message, MessagePriority } from '@/types'

const priorityColors: Record<MessagePriority, string> = {
  CRITICAL: 'text-error border-error/30 bg-error/10',
  HIGH: 'text-accent border-accent/30 bg-accent/10',
  MEDIUM: 'text-warning border-warning/30 bg-warning/10',
  LOW: 'text-info border-info/30 bg-info/10',
}

export default function MessagesPage() {
  const { t } = useLanguage()
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [composing, setComposing] = useState(false)
  const [newMsg, setNewMsg] = useState({ sender: 'R03', receiver: 'CONTROL', priority: 'CRITICAL' as MessagePriority, content: '' })

  const handleSend = () => {
    if (!newMsg.content.trim()) return
    const msg: Message = {
      id: `M${String(messages.length + 1).padStart(3, '0')}`,
      sender: newMsg.sender,
      receiver: newMsg.receiver,
      priority: newMsg.priority,
      content: newMsg.content,
      status: newMsg.sender === 'R03' ? 'WAITING' : 'QUEUED',
      timestamp: new Date().toLocaleTimeString('en-GB'),
      relayPath: newMsg.sender === 'R03' ? [newMsg.sender, 'R05', 'R02', 'CONTROL'] : undefined,
    }
    setMessages([msg, ...messages])
    setComposing(false)
    setNewMsg({ ...newMsg, content: '' })
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('messages')}</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">EMERGENCY MESSAGING</h1>
        </div>
        <button
          onClick={() => setComposing(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-white font-display text-xs tracking-micro uppercase rounded-md hover:bg-accent-light transition-all"
        >
          <Send className="w-4 h-4" /> {t('compose')}
        </button>
      </div>

      {/* Store-and-forward explanation */}
      <div className="glass rounded-lg p-4 flex items-start gap-3">
        <MessageSquare className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
        <p className="text-xs text-text-secondary leading-relaxed">
          {t('storeAndForward')} — Messages from offline robots are buffered and relayed through available nodes when a path becomes available.
        </p>
      </div>

      {/* Messages list */}
      <div className="space-y-3">
        {messages.map((msg, idx) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="glass rounded-lg p-4 hover:border-white/15 transition-all"
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono text-xs text-text-primary">{msg.sender} → {msg.receiver}</span>
                <span className={`px-2 py-0.5 text-[8px] tracking-micro uppercase font-medium rounded border ${priorityColors[msg.priority]}`}>
                  {t(msg.priority.toLowerCase())}
                </span>
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                {msg.status === 'DELIVERED' ? (
                  <><Check className="w-3 h-3 text-success" /><span className="text-[9px] tracking-micro text-success uppercase">{t('delivered')}</span></>
                ) : msg.status === 'WAITING' ? (
                  <><Clock className="w-3 h-3 text-warning blink" /><span className="text-[9px] tracking-micro text-warning uppercase">{t('waitingForRelay')}</span></>
                ) : msg.status === 'QUEUED' ? (
                  <><Clock className="w-3 h-3 text-info" /><span className="text-[9px] tracking-micro text-info uppercase">QUEUED</span></>
                ) : (
                  <><AlertCircle className="w-3 h-3 text-error" /><span className="text-[9px] tracking-micro text-error uppercase">FAILED</span></>
                )}
              </div>
            </div>
            <p className="text-sm text-text-primary">{msg.content}</p>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
              <span className="text-[9px] font-mono text-text-secondary">{msg.timestamp}</span>
              {msg.relayPath && (
                <div className="flex items-center gap-1">
                  <span className="text-[8px] tracking-micro text-text-secondary uppercase">RELAY:</span>
                  {msg.relayPath.map((node, i) => (
                    <span key={i} className="flex items-center gap-1">
                      <span className="font-mono text-[9px] text-text-secondary">{node}</span>
                      {i < msg.relayPath!.length - 1 && <span className="text-text-secondary/40">→</span>}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Compose modal */}
      <AnimatePresence>
        {composing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setComposing(false)}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-strong rounded-xl max-w-lg w-full p-6 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold tracking-tightest">{t('compose')}</h2>
                <button onClick={() => setComposing(false)} className="w-8 h-8 glass rounded-md flex items-center justify-center">
                  <X className="w-4 h-4 text-text-secondary" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] tracking-micro text-text-secondary uppercase mb-1.5">{t('robots')} (FROM)</label>
                  <select
                    value={newMsg.sender}
                    onChange={(e) => setNewMsg({ ...newMsg, sender: e.target.value })}
                    className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-md text-text-primary font-mono text-xs focus:outline-none focus:border-accent/40"
                  >
                    {['R01', 'R02', 'R03', 'R04', 'R05', 'R06'].map((r) => (
                      <option key={r} value={r} className="bg-bg-secondary">{r}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[9px] tracking-micro text-text-secondary uppercase mb-1.5">{t('priority')}</label>
                  <select
                    value={newMsg.priority}
                    onChange={(e) => setNewMsg({ ...newMsg, priority: e.target.value as MessagePriority })}
                    className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-md text-text-primary font-mono text-xs focus:outline-none focus:border-accent/40"
                  >
                    {['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((p) => (
                      <option key={p} value={p} className="bg-bg-secondary">{p}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[9px] tracking-micro text-text-secondary uppercase mb-1.5">MESSAGE</label>
                <textarea
                  value={newMsg.content}
                  onChange={(e) => setNewMsg({ ...newMsg, content: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-md text-text-primary text-sm focus:outline-none focus:border-accent/40 resize-none"
                  placeholder="Type emergency message..."
                />
              </div>
              <button
                onClick={handleSend}
                className="w-full py-3 bg-accent text-white font-display text-sm tracking-micro uppercase rounded-md hover:bg-accent-light transition-all flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" /> {t('send')}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
