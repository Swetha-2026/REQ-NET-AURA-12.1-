import { motion } from 'framer-motion'
import { MapPin, User, Clock, Target, AlertCircle } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { victims } from '@/data/mockData'
import type { VictimStatus, VictimPriority } from '@/types'

const statusConfig: Record<VictimStatus, { label: string; color: string; bg: string }> = {
  AWAITING_RESCUE: { label: 'AWAITING RESCUE', color: 'text-error', bg: 'bg-error/10 border-error/30' },
  IN_RESCUE: { label: 'IN RESCUE', color: 'text-warning', bg: 'bg-warning/10 border-warning/30' },
  RESCUED: { label: 'RESCUED', color: 'text-success', bg: 'bg-success/10 border-success/30' },
  DECEASED: { label: 'DECEASED', color: 'text-text-secondary', bg: 'bg-white/5 border-white/10' },
}

const priorityConfig: Record<VictimPriority, string> = {
  CRITICAL: 'text-error',
  HIGH: 'text-accent',
  MEDIUM: 'text-warning',
}

export default function VictimsPage() {
  const { t } = useLanguage()

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('victims')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">VICTIM DETECTION</h1>
      </div>

      {/* Map view */}
      <div
        className="relative aspect-[16/9] rounded-xl overflow-hidden border border-white/8 bg-bg-secondary mb-4"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)`,
          backgroundSize: '30px 30px',
        }}
      >
        <div className="absolute top-[15%] left-[10%] w-[25%] h-[30%] border border-error/20 bg-error/5 rounded-lg" />
        <div className="absolute top-[50%] left-[55%] w-[20%] h-[25%] border border-warning/20 bg-warning/5 rounded-lg" />

        {victims.map((victim, idx) => (
          <motion.div
            key={victim.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: idx * 0.1, type: 'spring' }}
            className="absolute"
            style={{ left: `${victim.position.x}%`, top: `${victim.position.y}%`, transform: 'translate(-50%, -50%)' }}
          >
            <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
              victim.status === 'AWAITING_RESCUE' ? 'border-error bg-error/20 pulse-glow' :
              victim.status === 'IN_RESCUE' ? 'border-warning bg-warning/20' :
              'border-success bg-success/20'
            }`}>
              <span className="font-mono text-[8px] text-text-primary font-bold">{victim.id.split('-')[1]}</span>
            </div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 whitespace-nowrap">
              <span className={`text-[8px] font-mono ${priorityConfig[victim.priority]}`}>{victim.id}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Victim cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {victims.map((victim, idx) => {
          const status = statusConfig[victim.status]
          return (
            <motion.div
              key={victim.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.08 }}
              className="glass rounded-lg p-5 hover:border-white/15 transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <p className="font-display text-xl font-bold text-text-primary">{victim.id}</p>
                <span className={`text-[9px] tracking-micro uppercase font-medium ${priorityConfig[victim.priority]}`}>
                  {t(victim.priority.toLowerCase())}
                </span>
              </div>

              <div className="space-y-2.5">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-text-secondary" />
                  <span className="text-xs text-text-secondary">{victim.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="w-3.5 h-3.5 text-text-secondary" />
                  <span className="text-xs text-text-secondary">{t('detectedBy')} <span className="text-text-primary font-mono">{victim.detectedBy}</span></span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-text-secondary" />
                  <span className="text-xs text-text-secondary">{t('detectedAt')} <span className="text-text-primary font-mono">{victim.detectedAt}</span></span>
                </div>
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-3.5 h-3.5 text-text-secondary" />
                  <span className="text-xs text-text-secondary">{t('confidence')} <span className="text-text-primary font-mono">{victim.confidence}%</span></span>
                </div>
              </div>

              <div className={`mt-4 px-3 py-2 rounded-md border ${status.bg} text-center`}>
                <span className={`text-[10px] tracking-micro uppercase font-medium ${status.color}`}>{status.label}</span>
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
