import { motion } from 'framer-motion'
import { Wifi, Activity, AlertCircle } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { robots, networkLinks } from '@/data/mockData'

export default function NetworkPage() {
  const { t } = useLanguage()

  const nodes = [
    { id: 'CONTROL', label: 'CTRL', x: 50, y: 8 },
    ...robots.map((r) => ({ id: r.id, label: r.id, x: r.position.x, y: r.position.y, status: r.status })),
  ]
  const getNode = (id: string) => nodes.find((n) => n.id === id)!

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('network')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">NETWORK TOPOLOGY</h1>
      </div>

      <div className="grid lg:grid-cols-[1fr_280px] gap-4">
        {/* Network graph */}
        <div className="glass rounded-xl p-6 relative aspect-square max-w-2xl mx-auto w-full">
          <svg viewBox="0 0 100 100" className="w-full h-full absolute inset-0 p-6" preserveAspectRatio="xMidYMid meet">
            {networkLinks.map((link, i) => {
              const from = getNode(link.from)
              const to = getNode(link.to)
              const color = link.status === 'ONLINE' ? '#3DD68C' : link.status === 'WEAK' ? '#FFB54D' : '#FF4D2E'
              return (
                <g key={i}>
                  <line
                    x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                    stroke={color}
                    strokeWidth={0.4}
                    strokeDasharray={link.status === 'WEAK' ? '1.5 1' : link.status === 'FAILED' ? '1 1.5' : undefined}
                    opacity={link.status === 'FAILED' ? 0.3 : 0.5}
                    className={link.status === 'WEAK' ? 'dash-anim' : ''}
                  />
                </g>
              )
            })}
          </svg>
          {nodes.map((node, idx) => (
            <motion.div
              key={node.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: idx * 0.1, type: 'spring' }}
              className="absolute"
              style={{ left: `${node.x}%`, top: `${node.y}%`, transform: 'translate(-50%, -50%)' }}
            >
              <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-lg flex items-center justify-center border-2 ${
                node.id === 'CONTROL' ? 'glass-strong border-white/30' :
                node.status === 'ONLINE' ? 'border-success/40 bg-success/10' :
                node.status === 'WARNING' ? 'border-warning/40 bg-warning/10' :
                'border-error/40 bg-error/10'
              }`}>
                <span className={`font-mono text-[10px] font-bold ${
                  node.id === 'CONTROL' ? 'text-text-primary' :
                  node.status === 'ONLINE' ? 'text-success' :
                  node.status === 'WARNING' ? 'text-warning' : 'text-error'
                }`}>{node.label}</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Link details */}
        <div className="glass rounded-lg p-5 space-y-3">
          <div className="flex items-center gap-2 mb-3">
            <Activity className="w-4 h-4 text-accent" />
            <h3 className="font-display text-xs font-medium tracking-micro uppercase">LINK STATUS</h3>
          </div>
          {networkLinks.map((link, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center justify-between py-2 border-b border-white/5 last:border-0"
            >
              <div className="flex items-center gap-2">
                <span className={`w-1.5 h-1.5 rounded-full ${
                  link.status === 'ONLINE' ? 'bg-success' : link.status === 'WEAK' ? 'bg-warning' : 'bg-error'
                }`} />
                <span className="font-mono text-xs text-text-primary">{link.from} → {link.to}</span>
              </div>
              <div className="text-right">
                <span className={`text-[9px] tracking-micro uppercase ${
                  link.status === 'ONLINE' ? 'text-success' : link.status === 'WEAK' ? 'text-warning' : 'text-error'
                }`}>{link.status}</span>
                <p className="text-[8px] font-mono text-text-secondary/60">{link.reliability}%</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Status summary */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: t('online'), count: networkLinks.filter((l) => l.status === 'ONLINE').length, icon: Wifi, color: 'text-success' },
          { label: t('weakLink'), count: networkLinks.filter((l) => l.status === 'WEAK').length, icon: Activity, color: 'text-warning' },
          { label: t('failedLink'), count: networkLinks.filter((l) => l.status === 'FAILED').length, icon: AlertCircle, color: 'text-error' },
        ].map((stat) => (
          <div key={stat.label} className="glass rounded-lg p-4 text-center">
            <stat.icon className={`w-5 h-5 ${stat.color} mx-auto mb-2`} />
            <p className="font-display text-2xl font-bold text-text-primary">{stat.count}</p>
            <p className="text-[9px] tracking-micro text-text-secondary uppercase mt-1">{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
