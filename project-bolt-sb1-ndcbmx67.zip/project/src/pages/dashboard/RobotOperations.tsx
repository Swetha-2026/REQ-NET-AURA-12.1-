import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Battery, Wifi, Clock, Percent, X, Crosshair, Route, Square } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { robots, robotImages } from '@/data/mockData'
import type { Robot } from '@/types'

export default function RobotOperations() {
  const { t } = useLanguage()
  const [selected, setSelected] = useState<Robot | null>(null)

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('robots')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">ROBOT OPERATIONS</h1>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {robots.map((robot, idx) => (
          <motion.div
            key={robot.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.08 }}
            className="group relative aspect-[4/5] rounded-xl overflow-hidden border border-white/5 hover:border-white/15 transition-all cursor-pointer"
            onClick={() => setSelected(robot)}
          >
            <img
              src={robotImages[robot.id]}
              alt={robot.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              style={{ filter: 'brightness(0.5) contrast(1.1)' }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/20 to-transparent" />
            {robot.status === 'OFFLINE' && <div className="absolute inset-0 bg-error/15" />}
            {robot.status === 'WARNING' && <div className="absolute inset-0 bg-warning/10" />}

            {/* Status dot */}
            <div className="absolute top-4 right-4 flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${
                robot.status === 'ONLINE' ? 'bg-success' : robot.status === 'WARNING' ? 'bg-warning' : 'bg-error'
              } ${robot.status === 'ONLINE' ? 'pulse-glow' : ''}`} />
              <span className={`text-[8px] tracking-micro uppercase font-medium ${
                robot.status === 'ONLINE' ? 'text-success' : robot.status === 'WARNING' ? 'text-warning' : 'text-error'
              }`}>{robot.status}</span>
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-5">
              <p className="font-display text-xl font-bold text-text-primary">{robot.id}</p>
              <p className="text-sm text-text-primary font-medium">{robot.name}</p>
              <p className="text-[10px] tracking-micro text-text-secondary uppercase mt-0.5">{robot.role}</p>
              <div className="grid grid-cols-3 gap-2 mt-4">
                <Metric icon={Battery} label={t('battery')} value={`${robot.battery}%`} />
                <Metric icon={Wifi} label={t('signal')} value={`${robot.rssi}`} />
                <Metric icon={Clock} label={t('latency')} value={`${robot.latency}ms`} />
              </div>
              <div className="flex gap-2 mt-4">
                <button
                  onClick={(e) => { e.stopPropagation(); setSelected(robot) }}
                  className="flex-1 py-2 text-[10px] tracking-micro uppercase font-medium border border-white/15 text-text-primary rounded-md hover:bg-white/5 transition-all"
                >
                  {t('track')}
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); setSelected(robot) }}
                  className="flex-1 py-2 text-[10px] tracking-micro uppercase font-medium bg-accent text-white rounded-md hover:bg-accent-light transition-all"
                >
                  {t('access')}
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Detail modal */}
      <AnimatePresence>
        {selected && (
          <RobotDetailModal robot={selected} onClose={() => setSelected(null)} />
        )}
      </AnimatePresence>
    </div>
  )
}

function Metric({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="text-center">
      <Icon className="w-3 h-3 text-text-secondary mx-auto mb-1" />
      <p className="font-mono text-[10px] text-text-primary">{value}</p>
      <p className="text-[7px] tracking-micro text-text-secondary uppercase mt-0.5">{label}</p>
    </div>
  )
}

function RobotDetailModal({ robot, onClose }: { robot: Robot; onClose: () => void }) {
  const { t } = useLanguage()

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="glass-strong rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="relative aspect-[16/9] overflow-hidden rounded-t-xl">
          <img src={robotImages[robot.id]} alt={robot.name} className="w-full h-full object-cover" style={{ filter: 'brightness(0.6) contrast(1.1)' }} />
          <div className="absolute inset-0 bg-gradient-to-t from-bg-secondary via-transparent to-transparent" />
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 glass-strong rounded-md flex items-center justify-center hover:bg-white/10">
            <X className="w-4 h-4 text-text-primary" />
          </button>
          <div className="absolute bottom-4 left-4">
            <p className="font-display text-3xl font-bold text-text-primary">{robot.id}</p>
            <p className="text-sm text-text-primary">{robot.name}</p>
            <span className={`inline-block mt-2 px-2 py-0.5 text-[9px] tracking-micro uppercase font-medium rounded ${
              robot.status === 'ONLINE' ? 'bg-success/20 text-success' :
              robot.status === 'WARNING' ? 'bg-warning/20 text-warning' : 'bg-error/20 text-error'
            }`}>{robot.status}</span>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Telemetry grid */}
          <div>
            <h3 className="font-display text-xs font-medium tracking-micro uppercase text-accent mb-3">{t('telemetry')}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: t('battery'), value: `${robot.battery}%`, icon: Battery },
                { label: t('signal'), value: `${robot.rssi} dBm`, icon: Wifi },
                { label: t('latency'), value: `${robot.latency} ms`, icon: Clock },
                { label: t('packetLoss'), value: `${robot.packetLoss}%`, icon: Percent },
              ].map((item) => (
                <div key={item.label} className="glass rounded-lg p-4">
                  <item.icon className="w-4 h-4 text-text-secondary mb-2" />
                  <p className="font-mono text-lg text-text-primary">{item.value}</p>
                  <p className="text-[9px] tracking-micro text-text-secondary uppercase mt-1">{item.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Position & mission */}
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="glass rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Crosshair className="w-4 h-4 text-text-secondary" />
                <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('position')}</span>
              </div>
              <p className="font-mono text-sm text-text-primary">{robot.zone}</p>
              <p className="font-mono text-xs text-text-secondary mt-1">X: {robot.position.x} Y: {robot.position.y}</p>
            </div>
            <div className="glass rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Route className="w-4 h-4 text-text-secondary" />
                <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('mission')}</span>
              </div>
              <p className="font-mono text-sm text-text-primary">{robot.mission || '—'}</p>
            </div>
          </div>

          {/* Network path */}
          <div className="glass rounded-lg p-4">
            <h4 className="text-[10px] tracking-micro text-text-secondary uppercase mb-3">{t('networkPath')}</h4>
            <div className="flex items-center gap-2 flex-wrap">
              {['CONTROL', 'R01', robot.id].map((node, i, arr) => (
                <div key={node} className="flex items-center gap-2">
                  <span className={`px-3 py-1.5 rounded-md font-mono text-xs ${
                    i === arr.length - 1 ? 'bg-accent/15 text-accent border border-accent/30' : 'bg-white/5 text-text-primary border border-white/10'
                  }`}>{node}</span>
                  {i < arr.length - 1 && <span className="text-text-secondary">→</span>}
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button className="flex-1 py-3 text-xs tracking-micro uppercase font-medium border border-white/15 text-text-primary rounded-md hover:bg-white/5 transition-all flex items-center justify-center gap-2">
              <Crosshair className="w-4 h-4" /> {t('track')}
            </button>
            <button className="flex-1 py-3 text-xs tracking-micro uppercase font-medium border border-white/15 text-text-primary rounded-md hover:bg-white/5 transition-all flex items-center justify-center gap-2">
              <Route className="w-4 h-4" /> {t('changeRoute')}
            </button>
            <button className="flex-1 py-3 text-xs tracking-micro uppercase font-medium bg-error/10 border border-error/30 text-error rounded-md hover:bg-error/20 transition-all flex items-center justify-center gap-2">
              <Square className="w-4 h-4" /> {t('emergencyStop')}
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}
