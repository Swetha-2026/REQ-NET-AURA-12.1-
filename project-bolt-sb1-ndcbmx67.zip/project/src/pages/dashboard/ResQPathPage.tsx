import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Route, RefreshCw, Check, AlertTriangle, Activity } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { robots, networkLinks } from '@/data/mockData'
import type { ResQPathResult } from '@/types'

export default function ResQPathPage() {
  const { t } = useLanguage()
  const [step, setStep] = useState(-1)
  const [result, setResult] = useState<ResQPathResult | null>(null)
  const [running, setRunning] = useState(false)

  const steps = [
    t('failureDetected'),
    t('networkAnalysis'),
    t('alternativeRelay') + ': R05',
    t('newRoute') + ': R02 → R05 → R04',
    t('routeRestored'),
  ]

  const runRecovery = () => {
    setRunning(true)
    setStep(0)
    setResult(null)
    let current = 0
    const timer = setInterval(() => {
      current++
      if (current >= steps.length) {
        clearInterval(timer)
        setRunning(false)
        setResult({
          status: 'recovered',
          failure: 'R03 offline',
          recommendedRelay: 'R05',
          route: ['R02', 'R05', 'R04'],
          reliability: 94,
          steps: steps,
        })
      } else {
        setStep(current)
      }
    }, 1200)
  }

  useEffect(() => {
    return () => setRunning(false)
  }, [])

  const nodes = [
    { id: 'CONTROL', x: 50, y: 8 },
    ...robots.map((r) => ({ id: r.id, x: r.position.x, y: r.position.y, status: r.status })),
  ]
  const getNode = (id: string) => nodes.find((n) => n.id === id)!

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">RESQPATH</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">SELF-HEALING ROUTING</h1>
        </div>
        <button
          onClick={runRecovery}
          disabled={running}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-white font-display text-xs tracking-micro uppercase rounded-md hover:bg-accent-light transition-all disabled:opacity-50 hover:shadow-[0_0_30px_rgba(255,77,46,0.25)]"
        >
          {running ? <Activity className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {running ? t('recovering') : 'RUN RECOVERY'}
        </button>
      </div>

      <div className="grid lg:grid-cols-[1fr_300px] gap-4">
        {/* Visualization */}
        <div className="glass rounded-xl p-6 relative aspect-square max-w-2xl mx-auto w-full">
          <svg viewBox="0 0 100 100" className="w-full h-full absolute inset-0 p-6" preserveAspectRatio="xMidYMid meet">
            {networkLinks.map((link, i) => {
              const from = getNode(link.from)
              const to = getNode(link.to)
              const isFailed = link.status === 'FAILED'
              const isRecovered = result && link.from === 'R02' && link.to === 'R05'
              const isActive = result && link.from === 'R05' && link.to === 'R04'
              const color = isFailed ? '#FF4D2E' : isRecovered || isActive ? '#FF7048' : '#3DD68C'
              return (
                <line
                  key={i}
                  x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                  stroke={color}
                  strokeWidth={isFailed ? 0.3 : 0.5}
                  strokeDasharray={isFailed ? '1 1.5' : undefined}
                  opacity={isFailed ? 0.3 : 0.6}
                  className={isRecovered || isActive ? 'dash-anim' : ''}
                />
              )
            })}
          </svg>
          {nodes.map((node) => {
            const isFailed = node.id === 'R03'
            const isRelay = result && node.id === 'R05'
            return (
              <div
                key={node.id}
                className="absolute"
                style={{ left: `${node.x}%`, top: `${node.y}%`, transform: 'translate(-50%, -50%)' }}
              >
                <div className={`w-11 h-11 sm:w-13 sm:h-13 rounded-lg flex items-center justify-center border-2 transition-all ${
                  isFailed ? 'border-error bg-error/20' :
                  isRelay ? 'border-accent bg-accent/20 pulse-glow' :
                  node.id === 'CONTROL' ? 'glass-strong border-white/30' :
                  node.status === 'ONLINE' ? 'border-success/40 bg-success/10' :
                  node.status === 'WARNING' ? 'border-warning/40 bg-warning/10' :
                  'border-error/40 bg-error/10'
                }`}>
                  <span className={`font-mono text-[9px] font-bold ${
                    isFailed ? 'text-error' : isRelay ? 'text-accent' :
                    node.id === 'CONTROL' ? 'text-text-primary' :
                    node.status === 'ONLINE' ? 'text-success' : 'text-text-secondary'
                  }`}>{node.id}</span>
                </div>
              </div>
            )
          })}
        </div>

        {/* Recovery steps */}
        <div className="glass rounded-lg p-5">
          <div className="flex items-center gap-2 mb-4">
            <Route className="w-4 h-4 text-accent" />
            <h3 className="font-display text-xs font-medium tracking-micro uppercase">RECOVERY LOG</h3>
          </div>
          <div className="space-y-3">
            {steps.map((s, i) => {
              const isActive = step >= i
              const isCurrent = step === i && running
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0.3 }}
                  animate={{ opacity: isActive ? 1 : 0.3 }}
                  className="flex items-start gap-3"
                >
                  <div className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                    isActive ? 'bg-accent/20 border border-accent/40' : 'bg-white/5 border border-white/10'
                  }`}>
                    {isActive && i < steps.length - 1 ? (
                      <Check className="w-3 h-3 text-accent" />
                    ) : isActive ? (
                      <Check className="w-3 h-3 text-success" />
                    ) : isCurrent ? (
                      <RefreshCw className="w-3 h-3 text-accent animate-spin" />
                    ) : null}
                  </div>
                  <p className={`text-xs font-mono ${isActive ? 'text-text-primary' : 'text-text-secondary'}`}>{s}</p>
                </motion.div>
              )
            })}
          </div>

          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-5 pt-5 border-t border-white/10 space-y-2"
            >
              <div className="flex justify-between text-xs">
                <span className="text-text-secondary">{t('failure')}:</span>
                <span className="font-mono text-error">{result.failure}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-text-secondary">{t('alternativeRelay')}:</span>
                <span className="font-mono text-accent">{result.recommendedRelay}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-text-secondary">{t('networkReliability')}:</span>
                <span className="font-mono text-success">{result.reliability}%</span>
              </div>
              <div className="flex items-center gap-2 mt-3 px-3 py-2 bg-success/10 rounded-md">
                <AlertTriangle className="w-3 h-3 text-success" />
                <span className="text-[10px] tracking-micro text-success uppercase">{t('recovered')}</span>
              </div>
            </motion.div>
          )}

          {!result && !running && (
            <p className="mt-5 text-[10px] text-text-secondary/60 font-mono text-center">
              PRESS "RUN RECOVERY" TO SIMULATE
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
