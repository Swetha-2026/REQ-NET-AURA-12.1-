import { motion } from 'framer-motion'
import { Target, MapPin, Bot, Route, Users, Clock } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { missions } from '@/data/mockData'
import type { MissionStatus, MissionPriority } from '@/types'

const statusConfig: Record<MissionStatus, { color: string; bg: string }> = {
  ACTIVE: { color: 'text-success', bg: 'bg-success/10 border-success/30' },
  PLANNED: { color: 'text-info', bg: 'bg-info/10 border-info/30' },
  COMPLETED: { color: 'text-text-secondary', bg: 'bg-white/5 border-white/10' },
  ABORTED: { color: 'text-error', bg: 'bg-error/10 border-error/30' },
}

const priorityConfig: Record<MissionPriority, string> = {
  CRITICAL: 'text-error',
  HIGH: 'text-accent',
  MEDIUM: 'text-warning',
  LOW: 'text-info',
}

export default function MissionsPage() {
  const { t } = useLanguage()

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('missions')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">MISSION MANAGEMENT</h1>
      </div>

      <div className="space-y-4">
        {missions.map((mission, idx) => {
          const status = statusConfig[mission.status]
          return (
            <motion.div
              key={mission.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.08 }}
              className="glass rounded-lg p-5 hover:border-white/15 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-display text-lg font-bold text-text-primary">{mission.id}</p>
                    <span className={`text-[9px] tracking-micro uppercase font-medium ${priorityConfig[mission.priority]}`}>
                      {t(mission.priority.toLowerCase())}
                    </span>
                  </div>
                  <p className="text-sm text-text-primary">{mission.name}</p>
                </div>
                <div className={`px-3 py-1.5 rounded-md border ${status.bg} flex-shrink-0`}>
                  <span className={`text-[10px] tracking-micro uppercase font-medium ${status.color}`}>{t(mission.status.toLowerCase())}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                <Info icon={MapPin} label={t('zone')} value={mission.zone} />
                <Info icon={Bot} label={t('assignedRobot')} value={mission.robot} />
                <Info icon={Users} label={t('victims')} value={String(mission.victims.length)} />
                <Info icon={Clock} label={t('timeline')} value={mission.createdAt} />
              </div>

              {/* Progress bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('missionProgress')}</span>
                  <span className="font-mono text-xs text-text-primary">{mission.progress}%</span>
                </div>
                <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${mission.progress}%` }}
                    transition={{ delay: idx * 0.08 + 0.3, duration: 0.8 }}
                    className={`h-full rounded-full ${mission.status === 'COMPLETED' ? 'bg-success' : 'bg-accent'}`}
                  />
                </div>
              </div>

              {/* Route */}
              <div className="flex items-center gap-2 flex-wrap pt-3 border-t border-white/5">
                <Route className="w-3.5 h-3.5 text-text-secondary" />
                <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('route')}:</span>
                {mission.route.map((node, i) => (
                  <span key={i} className="flex items-center gap-1">
                    <span className="font-mono text-[10px] text-text-primary px-2 py-0.5 bg-white/5 rounded">{node}</span>
                    {i < mission.route.length - 1 && <span className="text-text-secondary/40">→</span>}
                  </span>
                ))}
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

function Info({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-1">
        <Icon className="w-3 h-3 text-text-secondary" />
        <span className="text-[9px] tracking-micro text-text-secondary uppercase">{label}</span>
      </div>
      <p className="font-mono text-xs text-text-primary">{value}</p>
    </div>
  )
}
