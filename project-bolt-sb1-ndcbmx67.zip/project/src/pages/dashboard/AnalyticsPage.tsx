import { motion } from 'framer-motion'
import { TrendingUp, Zap, Bot, MessageSquare, Route, Battery, Activity } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { analytics } from '@/data/mockData'

export default function AnalyticsPage() {
  const { t } = useLanguage()

  const metrics = [
    { label: t('networkReliability'), value: `${analytics.networkReliability}%`, icon: Activity, color: 'text-success', history: analytics.reliabilityHistory, suffix: '%' },
    { label: t('avgLatency'), value: `${analytics.avgLatency}ms`, icon: Zap, color: 'text-warning', history: analytics.latencyHistory, suffix: 'ms' },
    { label: t('packetLoss'), value: `${analytics.packetLoss}%`, icon: TrendingUp, color: 'text-error', history: analytics.packetLossHistory, suffix: '%' },
    { label: t('robotAvailability'), value: `${analytics.robotAvailability}%`, icon: Bot, color: 'text-info', static: true },
    { label: t('messageDelivery'), value: `${analytics.messageDelivery}%`, icon: MessageSquare, color: 'text-success', static: true },
    { label: t('routeRecovery'), value: `${analytics.routeRecovery}%`, icon: Route, color: 'text-accent', static: true },
    { label: t('batteryHealth'), value: `${analytics.batteryHealth}%`, icon: Battery, color: 'text-warning', static: true },
  ]

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('analytics')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">NETWORK ANALYTICS</h1>
      </div>

      {/* Key metrics with charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        {metrics.slice(0, 3).map((metric, idx) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="glass rounded-lg p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <metric.icon className={`w-4 h-4 ${metric.color}`} />
                <h3 className="text-[10px] tracking-micro text-text-secondary uppercase">{metric.label}</h3>
              </div>
              <span className={`font-display text-2xl font-bold ${metric.color}`}>{metric.value}</span>
            </div>
            {/* Mini chart */}
            <div className="flex items-end gap-1 h-20">
              {metric.history?.map((val, i) => {
                const max = Math.max(...metric.history!)
                const min = Math.min(...metric.history!)
                const range = max - min || 1
                const height = ((val - min) / range) * 80 + 20
                return (
                  <motion.div
                    key={i}
                    initial={{ height: 0 }}
                    animate={{ height: `${height}%` }}
                    transition={{ delay: idx * 0.1 + i * 0.03, type: 'spring' }}
                    className={`flex-1 rounded-sm min-h-[4px] ${metric.color.replace('text-', 'bg-')}/40`}
                    style={{ backgroundColor: 'currentColor', opacity: 0.3 + (val / max) * 0.5 }}
                  />
                )
              })}
            </div>
            <div className="flex justify-between mt-2 text-[8px] font-mono text-text-secondary/50">
              <span>12H</span>
              <span>NOW</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Secondary metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {metrics.slice(3).map((metric, idx) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + idx * 0.08 }}
            className="glass rounded-lg p-5 text-center"
          >
            <metric.icon className={`w-5 h-5 ${metric.color} mx-auto mb-2`} />
            <p className={`font-display text-2xl font-bold ${metric.color}`}>{metric.value}</p>
            <p className="text-[9px] tracking-micro text-text-secondary uppercase mt-1">{metric.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Reliability trend - large chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="glass rounded-lg p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-accent" />
            <h3 className="font-display text-sm font-medium tracking-micro uppercase">{t('networkReliability')} — 12H TREND</h3>
          </div>
          <span className="font-mono text-sm text-success">{analytics.networkReliability}%</span>
        </div>
        <div className="relative h-48 flex items-end gap-2">
          {analytics.reliabilityHistory.map((val, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${val}%` }}
                transition={{ delay: 0.5 + i * 0.05, type: 'spring' }}
                className="w-full bg-gradient-to-t from-accent/20 to-accent/60 rounded-sm min-h-[8px] relative group-hover:from-accent/40 group-hover:to-accent/80 transition-all"
              >
                <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-mono text-text-primary opacity-0 group-hover:opacity-100 transition-opacity">{val}%</span>
              </motion.div>
              <span className="text-[8px] font-mono text-text-secondary/50">-{12 - i}h</span>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}
