import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Globe, Bell, FlaskConical, Network, Eye, Palette, Check
} from 'lucide-react'
import { useLanguage, languages } from '@/contexts/LanguageContext'
import type { LanguageCode } from '@/data/translations'

export default function SettingsPage() {
  const { t, lang, setLang } = useLanguage()
  const [notifications, setNotifications] = useState(true)
  const [simulationMode, setSimulationMode] = useState(true)
  const [highContrast, setHighContrast] = useState(false)
  const [reducedMotion, setReducedMotion] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('settings')}</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">SYSTEM SETTINGS</h1>
        </div>
        <button
          onClick={handleSave}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-white font-display text-xs tracking-micro uppercase rounded-md hover:bg-accent-light transition-all"
        >
          {saved ? <Check className="w-4 h-4" /> : null}
          {saved ? 'SAVED' : t('save')}
        </button>
      </div>

      <div className="space-y-4">
        {/* Language */}
        <SettingsSection icon={Globe} title={t('language')}>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
            {languages.map((language) => (
              <button
                key={language.code}
                onClick={() => setLang(language.code as LanguageCode)}
                className={`flex items-center justify-between px-3 py-2.5 rounded-md border text-left transition-all ${
                  lang === language.code
                    ? 'border-accent/40 bg-accent/10 text-text-primary'
                    : 'border-white/8 bg-white/[0.02] text-text-secondary hover:border-white/15'
                }`}
              >
                <span className="text-xs font-medium">{language.nativeName}</span>
                {lang === language.code && <Check className="w-3 h-3 text-accent" />}
              </button>
            ))}
          </div>
        </SettingsSection>

        {/* Notifications */}
        <SettingsSection icon={Bell} title={t('notifications')}>
          <ToggleRow label={t('notifications')} value={notifications} onChange={setNotifications} />
        </SettingsSection>

        {/* Simulation mode */}
        <SettingsSection icon={FlaskConical} title={t('simulationMode')}>
          <ToggleRow label={t('simulationMode')} value={simulationMode} onChange={setSimulationMode} />
        </SettingsSection>

        {/* Network preferences */}
        <SettingsSection icon={Network} title={t('networkPreferences')}>
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-text-secondary">Auto-route recovery threshold</span>
              <span className="font-mono text-xs text-text-primary">70%</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-text-secondary">Max hop count</span>
              <span className="font-mono text-xs text-text-primary">4</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-text-secondary">Heartbeat interval</span>
              <span className="font-mono text-xs text-text-primary">5s</span>
            </div>
          </div>
        </SettingsSection>

        {/* Accessibility */}
        <SettingsSection icon={Eye} title={t('accessibility')}>
          <ToggleRow label="High contrast" value={highContrast} onChange={setHighContrast} />
          <ToggleRow label="Reduced motion" value={reducedMotion} onChange={setReducedMotion} />
        </SettingsSection>

        {/* Theme */}
        <SettingsSection icon={Palette} title={t('themePreferences')}>
          <div className="flex gap-3">
            <div className="flex-1 p-4 rounded-lg border-2 border-accent/40 bg-accent/5 text-center cursor-pointer">
              <div className="w-full h-12 rounded-md bg-bg-primary border border-white/10 mb-2" />
              <span className="text-[10px] tracking-micro text-accent uppercase">{t('enabled')}</span>
            </div>
            <div className="flex-1 p-4 rounded-lg border border-white/8 bg-white/[0.02] text-center cursor-pointer opacity-50">
              <div className="w-full h-12 rounded-md bg-white border border-white/20 mb-2" />
              <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('disabled')}</span>
            </div>
          </div>
        </SettingsSection>
      </div>
    </div>
  )
}

function SettingsSection({ icon: Icon, title, children }: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-lg p-5"
    >
      <div className="flex items-center gap-2 mb-4">
        <Icon className="w-4 h-4 text-accent" />
        <h3 className="font-display text-xs font-medium tracking-micro uppercase">{title}</h3>
      </div>
      {children}
    </motion.div>
  )
}

function ToggleRow({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  const { t } = useLanguage()
  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-xs text-text-secondary">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-11 h-6 rounded-full transition-colors ${value ? 'bg-accent' : 'bg-white/10'}`}
      >
        <motion.div
          layout
          className="absolute top-0.5 w-5 h-5 rounded-full bg-white"
          animate={{ left: value ? 22 : 2 }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  )
}
