import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import { ZoomIn, ZoomOut, Locate, Search, Layers } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { robots, victims, networkLinks } from '@/data/mockData'

export default function TacticalMap() {
  const { t } = useLanguage()
  const [zoom, setZoom] = useState(1)
  const [search, setSearch] = useState('')
  const mapRef = useRef<HTMLDivElement>(null)

  const allNodes = [
    { id: 'CONTROL', label: 'CTRL', x: 50, y: 8, type: 'control' as const },
    ...robots.map((r) => ({ id: r.id, label: r.id, x: r.position.x, y: r.position.y, type: r.status.toLowerCase() as string })),
    ...victims.map((v) => ({ id: v.id, label: v.id, x: v.position.x, y: v.position.y, type: 'victim' as const })),
  ]

  const getNode = (id: string) => allNodes.find((n) => n.id === id)

  const filteredRobots = search
    ? robots.filter((r) => r.id.toLowerCase().includes(search.toLowerCase()) || r.name.toLowerCase().includes(search.toLowerCase()))
    : robots

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('map')}</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">TACTICAL MAP</h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-text-secondary" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t('search')}
              className="pl-8 pr-3 py-2 bg-white/[0.03] border border-white/10 rounded-md text-xs font-mono text-text-primary focus:outline-none focus:border-accent/40 w-32 sm:w-40"
            />
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_200px] gap-4">
        {/* Map */}
        <div
          ref={mapRef}
          className="relative aspect-[4/3] rounded-xl overflow-hidden border border-white/8 bg-bg-secondary"
          style={{
            backgroundImage: `
              radial-gradient(circle at 30% 40%, rgba(255,77,46,0.04) 0%, transparent 30%),
              radial-gradient(circle at 70% 60%, rgba(255,181,77,0.03) 0%, transparent 25%),
              linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)
            `,
            backgroundSize: '100% 100%, 100% 100%, 30px 30px, 30px 30px',
          }}
        >
          {/* Zone overlays */}
          <div className="absolute top-[15%] left-[10%] w-[25%] h-[30%] border border-error/20 bg-error/5 rounded-lg" />
          <div className="absolute top-[15%] left-[10%] px-2 py-0.5 text-[8px] font-mono tracking-micro text-error/60 uppercase">ZONE C — DAMAGED</div>

          <div className="absolute top-[50%] left-[60%] w-[20%] h-[25%] border border-warning/20 bg-warning/5 rounded-lg" />
          <div className="absolute top-[50%] left-[60%] px-2 py-0.5 text-[8px] font-mono tracking-micro text-warning/60 uppercase">HAZARD</div>

          <div className="absolute top-[20%] right-[5%] w-[15%] h-[20%] border border-success/15 bg-success/5 rounded-lg" />
          <div className="absolute top-[20%] right-[5%] px-2 py-0.5 text-[8px] font-mono tracking-micro text-success/60 uppercase">RESCUE</div>

          {/* SVG links */}
          <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full" preserveAspectRatio="none" style={{ transform: `scale(${zoom})`, transformOrigin: 'center' }}>
            {networkLinks.map((link, i) => {
              const from = getNode(link.from)
              const to = getNode(link.to)
              if (!from || !to) return null
              const color = link.status === 'ONLINE' ? '#3DD68C' : link.status === 'WEAK' ? '#FFB54D' : '#FF4D2E'
              return (
                <line
                  key={i}
                  x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                  stroke={color}
                  strokeWidth={0.3}
                  strokeDasharray={link.status === 'WEAK' ? '1.5 1' : link.status === 'FAILED' ? '1 1.5' : undefined}
                  opacity={link.status === 'FAILED' ? 0.4 : 0.6}
                  className={link.status === 'WEAK' ? 'dash-anim' : ''}
                />
              )
            })}
          </svg>

          {/* Nodes */}
          {allNodes.map((node) => (
            <motion.div
              key={node.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', delay: 0.1 + Math.random() * 0.3 }}
              className="absolute flex flex-col items-center"
              style={{ left: `${node.x}%`, top: `${node.y}%`, transform: `translate(-50%, -50%) scale(${zoom})` }}
            >
              {node.type === 'control' ? (
                <div className="w-10 h-10 rounded-lg glass-strong border border-white/30 flex items-center justify-center">
                  <span className="font-mono text-[8px] text-text-primary font-bold">CTRL</span>
                </div>
              ) : node.type === 'victim' ? (
                <div className="w-6 h-6 rounded-full border-2 border-warning bg-warning/20 flex items-center justify-center pulse-glow">
                  <span className="font-mono text-[7px] text-warning font-bold">V</span>
                </div>
              ) : (
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center border-2 ${
                  node.type === 'online' ? 'border-success bg-success/15' :
                  node.type === 'warning' ? 'border-warning bg-warning/15' :
                  'border-error bg-error/15'
                }`}>
                  <span className={`font-mono text-[8px] font-bold ${
                    node.type === 'online' ? 'text-success' :
                    node.type === 'warning' ? 'text-warning' : 'text-error'
                  }`}>{node.label}</span>
                </div>
              )}
              <span className="mt-1 text-[7px] font-mono text-text-secondary whitespace-nowrap">{node.id}</span>
            </motion.div>
          ))}

          {/* Map controls */}
          <div className="absolute bottom-3 right-3 flex flex-col gap-1">
            <button onClick={() => setZoom((z) => Math.min(z + 0.2, 2))} className="w-8 h-8 glass-strong rounded-md flex items-center justify-center hover:bg-white/10 transition-colors">
              <ZoomIn className="w-4 h-4 text-text-primary" />
            </button>
            <button onClick={() => setZoom((z) => Math.max(z - 0.2, 0.5))} className="w-8 h-8 glass-strong rounded-md flex items-center justify-center hover:bg-white/10 transition-colors">
              <ZoomOut className="w-4 h-4 text-text-primary" />
            </button>
            <button onClick={() => setZoom(1)} className="w-8 h-8 glass-strong rounded-md flex items-center justify-center hover:bg-white/10 transition-colors">
              <Locate className="w-4 h-4 text-text-primary" />
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="glass rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-2 mb-2">
            <Layers className="w-4 h-4 text-accent" />
            <h3 className="font-display text-xs font-medium tracking-micro uppercase">{t('legend')}</h3>
          </div>
          {[
            { label: t('online'), color: 'bg-success', dot: 'w-2.5 h-2.5 rounded-full' },
            { label: t('warning'), color: 'bg-warning', dot: 'w-2.5 h-2.5 rounded-full' },
            { label: t('offline'), color: 'bg-error', dot: 'w-2.5 h-2.5 rounded-full' },
            { label: t('activeRoute'), color: 'bg-success', dot: 'w-4 h-0.5' },
            { label: t('weakLink'), color: 'bg-warning', dot: 'w-4 h-0.5' },
            { label: t('failedLink'), color: 'bg-error', dot: 'w-4 h-0.5' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <span className={`${item.dot} ${item.color}`} />
              <span className="text-[10px] tracking-micro text-text-secondary uppercase">{item.label}</span>
            </div>
          ))}
          <div className="pt-2 border-t border-white/5">
            <p className="text-[9px] font-mono text-text-secondary/60 mb-2">{filteredRobots.length} {t('robots')}</p>
            {filteredRobots.slice(0, 4).map((r) => (
              <div key={r.id} className="flex items-center justify-between py-1">
                <span className="font-mono text-[10px] text-text-primary">{r.id}</span>
                <span className={`text-[8px] tracking-micro uppercase ${
                  r.status === 'ONLINE' ? 'text-success' : r.status === 'WARNING' ? 'text-warning' : 'text-error'
                }`}>{r.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
