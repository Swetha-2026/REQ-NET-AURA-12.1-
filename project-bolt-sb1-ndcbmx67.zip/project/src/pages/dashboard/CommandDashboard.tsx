import { motion } from 'framer-motion'
import {
  Activity, AlertTriangle, Bot, Radio, Zap, TrendingUp,
  ArrowRight, Wifi, Users, Target
} from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { robots, alerts, missions, victims, analytics } from '@/data/mockData'

export default function CommandDashboard({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useLanguage()

  const onlineRobots = robots.filter((r) => r.status === 'ONLINE').length
  const criticalAlerts = alerts.filter((a) => a.severity === 'CRITICAL' && !a.acknowledged).length
  const activeMissions = missions.filter((m) => m.status === 'ACTIVE').length
  const awaitingVictims = victims.filter((v) => v.status === 'AWAITING_RESCUE').length

  const stats = [
    { label: t('robots'), value: `${onlineRobots}/6`, icon: Bot, color: 'text-success', page: 'ROBOTS' },
    { label: t('alerts'), value: criticalAlerts, icon: AlertTriangle, color: 'text-accent', page: 'ALERTS' },
    { label: t('missions'), value: activeMissions, icon: Target, color: 'text-info', page: 'MISSIONS' },
    { label: t('victims'), value: awaitingVictims, icon: Users, color: 'text-warning', page: 'VICTIMS' },
  ]

  return (
    <div className="space-y-6">
      {/* Overview header */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-end justify-between gap-4"
      >
        <div>
          <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-2">{t('command')} — OVERVIEW</p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tightest">LIVE OPERATIONS</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-success pulse-glow" />
          <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('status')} {t('online')}</span>
        </div>
      </motion.div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat, idx) => (
          <motion.button
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.08 }}
            onClick={() => onNavigate(stat.page)}
            className="group glass rounded-lg p-5 text-left hover:border-white/20 transition-all relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-white/[0.02] to-transparent rounded-bl-full" />
            <stat.icon className={`w-5 h-5 ${stat.color} mb-3`} />
            <p className="font-display text-2xl font-bold text-text-primary">{stat.value}</p>
            <p className="text-[10px] tracking-micro text-text-secondary uppercase mt-1">{stat.label}</p>
            <ArrowRight className="absolute bottom-4 right-4 w-4 h-4 text-text-secondary opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
          </motion.button>
        ))}
      </div>

      {/* Main grid */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Network status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-lg p-6 lg:col-span-2"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-accent" />
              <h2 className="font-display text-sm font-medium tracking-micro uppercase">{t('networkReliability')}</h2>
            </div>
            <span className="font-mono text-xs text-success">{analytics.networkReliability}%</span>
          </div>
          {/* Mini chart */}
          <div className="flex items-end gap-1.5 h-24">
            {analytics.reliabilityHistory.map((val, i) => (
              <motion.div
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${val}%` }}
                transition={{ delay: 0.4 + i * 0.05, type: 'spring' }}
                className="flex-1 bg-gradient-to-t from-accent/30 to-accent/60 rounded-sm min-h-[8px]"
                style={{ height: `${val}%` }}
              />
            ))}
          </div>
          <div className="flex justify-between mt-3 text-[9px] font-mono text-text-secondary/60">
            <span>12H AGO</span>
            <span>NOW</span>
          </div>
        </motion.div>

        {/* Quick metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-lg p-6 space-y-4"
        >
          <h2 className="font-display text-sm font-medium tracking-micro uppercase mb-4">METRICS</h2>
          {[
            { label: t('avgLatency'), value: `${analytics.avgLatency}ms`, icon: Zap },
            { label: t('packetLoss'), value: `${analytics.packetLoss}%`, icon: TrendingUp },
            { label: t('messageDelivery'), value: `${analytics.messageDelivery}%`, icon: Radio },
            { label: t('robotAvailability'), value: `${analytics.robotAvailability}%`, icon: Bot },
          ].map((metric) => (
            <div key={metric.label} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <metric.icon className="w-4 h-4 text-text-secondary" />
                <span className="text-xs text-text-secondary">{metric.label}</span>
              </div>
              <span className="font-mono text-sm text-text-primary">{metric.value}</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Active robots + recent alerts */}
      <div className="grid lg:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-lg p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-sm font-medium tracking-micro uppercase">{t('robots')}</h2>
            <button onClick={() => onNavigate('ROBOTS')} className="text-[10px] tracking-micro text-accent hover:text-accent-light uppercase">VIEW ALL →</button>
          </div>
          <div className="space-y-2">
            {robots.slice(0, 4).map((robot) => (
              <div key={robot.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                <div className="flex items-center gap-3">
                  <span className={`w-2 h-2 rounded-full ${
                    robot.status === 'ONLINE' ? 'bg-success' : robot.status === 'WARNING' ? 'bg-warning' : 'bg-error'
                  } ${robot.status === 'ONLINE' ? 'pulse-glow' : ''}`} />
                  <div>
                    <p className="font-mono text-xs text-text-primary">{robot.id} — {robot.name}</p>
                    <p className="text-[9px] tracking-micro text-text-secondary uppercase">{robot.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-[10px] font-mono text-text-secondary">
                  <span>{robot.battery}%</span>
                  <span>{robot.rssi}dBm</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass rounded-lg p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-sm font-medium tracking-micro uppercase">{t('alerts')}</h2>
            <button onClick={() => onNavigate('ALERTS')} className="text-[10px] tracking-micro text-accent hover:text-accent-light uppercase">VIEW ALL →</button>
          </div>
          <div className="space-y-2">
            {alerts.slice(0, 4).map((alert) => (
              <div key={alert.id} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                <span className={`w-1 h-8 rounded-full ${
                  alert.severity === 'CRITICAL' ? 'bg-error' : alert.severity === 'HIGH' ? 'bg-accent' : alert.severity === 'WARNING' ? 'bg-warning' : 'bg-success'
                }`} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-text-primary truncate">{alert.title}</p>
                  <p className="text-[9px] text-text-secondary font-mono">{alert.timestamp}</p>
                </div>
                <span className={`text-[8px] tracking-micro uppercase font-medium ${
                  alert.severity === 'CRITICAL' ? 'text-error' : alert.severity === 'HIGH' ? 'text-accent' : alert.severity === 'WARNING' ? 'text-warning' : 'text-success'
                }`}>{t(alert.severity.toLowerCase())}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
