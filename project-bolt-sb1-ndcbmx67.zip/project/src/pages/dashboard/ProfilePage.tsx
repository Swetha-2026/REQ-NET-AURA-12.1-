import { motion } from 'framer-motion'
import { User, Shield, Target, Clock, MapPin, Activity } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { useAuth } from '@/contexts/AuthContext'

export default function ProfilePage() {
  const { t } = useLanguage()
  const { user } = useAuth()

  if (!user) return null

  const fields = [
    { label: t('operatorName'), value: user.name, icon: User },
    { label: 'Role', value: user.role, icon: Shield },
    { label: t('activeMission'), value: user.activeMission || '—', icon: Target },
    { label: t('accessLevel'), value: user.accessLevel, icon: Shield },
    { label: t('lastActivity'), value: user.lastActivity, icon: Clock },
    { label: t('networkRegion'), value: user.region, icon: MapPin },
  ]

  return (
    <div className="space-y-4">
      <div>
        <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('profile')}</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">OPERATOR PROFILE</h1>
      </div>

      <div className="grid lg:grid-cols-[1fr_2fr] gap-4">
        {/* Profile card */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass rounded-xl p-6 text-center"
        >
          <div className="w-20 h-20 mx-auto rounded-full bg-accent/15 border border-accent/30 flex items-center justify-center mb-4">
            <User className="w-8 h-8 text-accent" />
          </div>
          <p className="font-display text-lg font-bold text-text-primary">{user.name}</p>
          <p className="font-mono text-xs text-text-secondary mt-1">@{user.username}</p>
          <div className="mt-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-md border border-accent/20 bg-accent/5">
            <span className="w-1.5 h-1.5 rounded-full bg-accent pulse-glow" />
            <span className="text-[10px] tracking-micro text-accent uppercase">{user.role}</span>
          </div>
          <div className="mt-6 pt-6 border-t border-white/5">
            <div className="flex items-center justify-center gap-2">
              <Activity className="w-3 h-3 text-success" />
              <span className="text-[10px] tracking-micro text-success uppercase">{t('online')}</span>
            </div>
          </div>
        </motion.div>

        {/* Details */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass rounded-xl p-6"
        >
          <h3 className="font-display text-sm font-medium tracking-micro uppercase mb-5">OPERATOR DETAILS</h3>
          <div className="space-y-1">
            {fields.map((field, idx) => (
              <motion.div
                key={field.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.08 }}
                className="flex items-center gap-4 py-3 border-b border-white/5 last:border-0"
              >
                <field.icon className="w-4 h-4 text-text-secondary flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] tracking-micro text-text-secondary uppercase">{field.label}</p>
                  <p className="text-sm text-text-primary font-mono mt-0.5">{field.value}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
