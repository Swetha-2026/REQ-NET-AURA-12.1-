import { useState } from 'react'
import { motion } from 'framer-motion'
import { Bell, Check, AlertTriangle, Info, CheckCircle } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { alerts as initialAlerts } from '@/data/mockData'
import type { Alert, AlertSeverity } from '@/types'

const severityConfig: Record<AlertSeverity, { icon: React.ComponentType<{ className?: string }>; color: string; bg: string; border: string }> = {
  CRITICAL: { icon: AlertTriangle, color: 'text-error', bg: 'bg-error/10', border: 'border-error/30' },
  HIGH: { icon: Bell, color: 'text-accent', bg: 'bg-accent/10', border: 'border-accent/30' },
  WARNING: { icon: Info, color: 'text-warning', bg: 'bg-warning/10', border: 'border-warning/30' },
  SUCCESS: { icon: CheckCircle, color: 'text-success', bg: 'bg-success/10', border: 'border-success/30' },
}

export default function AlertsPage() {
  const { t } = useLanguage()
  const [alerts, setAlerts] = useState<Alert[]>(initialAlerts)

  const acknowledge = (id: string) => {
    setAlerts(alerts.map((a) => a.id === id ? { ...a, acknowledged: true } : a))
  }

  const unacknowledged = alerts.filter((a) => !a.acknowledged).length

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-micro text-accent uppercase mb-1">{t('alerts')}</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tightest">EMERGENCY ALERTS</h1>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-accent/20 bg-accent/5">
          <span className="w-1.5 h-1.5 rounded-full bg-accent pulse-glow" />
          <span className="text-[10px] tracking-micro text-accent uppercase">{unacknowledged} UNACKNOWLEDGED</span>
        </div>
      </div>

      <div className="space-y-3">
        {alerts.map((alert, idx) => {
          const config = severityConfig[alert.severity]
          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.06 }}
              className={`glass rounded-lg p-4 border-l-4 ${alert.acknowledged ? 'opacity-50' : ''}`}
              style={{ borderColor: alert.severity === 'CRITICAL' ? '#FF4D2E' : alert.severity === 'HIGH' ? '#FF7048' : alert.severity === 'WARNING' ? '#FFB54D' : '#3DD68C' }}
            >
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-lg ${config.bg} ${config.border} border flex items-center justify-center flex-shrink-0`}>
                  <config.icon className={`w-4 h-4 ${config.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className={`text-[9px] tracking-micro uppercase font-medium ${config.color}`}>{t(alert.severity.toLowerCase())}</span>
                    {alert.acknowledged && <span className="text-[9px] tracking-micro text-text-secondary uppercase">· {t('acknowledged')}</span>}
                  </div>
                  <p className="text-sm font-medium text-text-primary">{alert.title}</p>
                  <p className="text-xs text-text-secondary mt-1">{alert.description}</p>
                  <p className="text-[9px] font-mono text-text-secondary/60 mt-2">{alert.timestamp}</p>
                </div>
                {!alert.acknowledged && (
                  <button
                    onClick={() => acknowledge(alert.id)}
                    className="px-3 py-1.5 text-[10px] tracking-micro uppercase font-medium border border-white/15 text-text-secondary rounded-md hover:text-text-primary hover:bg-white/5 transition-all flex items-center gap-1.5 flex-shrink-0"
                  >
                    <Check className="w-3 h-3" /> {t('acknowledge')}
                  </button>
                )}
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
