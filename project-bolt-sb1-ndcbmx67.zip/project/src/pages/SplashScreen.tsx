import { motion } from 'framer-motion'
import { useLanguage } from '@/contexts/LanguageContext'
import { heroRobotImage } from '@/data/mockData'

export default function SplashScreen({ onComplete }: { onComplete: () => void }) {
  const { t } = useLanguage()

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-bg-primary noise-overlay"
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
    >
      <div className="absolute inset-0 grid-pattern opacity-40" />
      <div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse 60% 80% at 50% 50%, rgba(255,77,46,0.08) 0%, transparent 70%)',
        }}
      />

      <motion.div
        initial={{ scale: 1.1, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.4 }}
        transition={{ duration: 2, ease: 'easeOut' }}
        className="relative z-10"
      >
        <img
          src={heroRobotImage}
          alt=""
          className="w-[280px] sm:w-[400px] h-auto object-contain float-anim"
          style={{ filter: 'brightness(0.7) contrast(1.1)' }}
        />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        className="absolute bottom-[20%] z-20 text-center px-6"
      >
        <h1 className="font-display text-5xl sm:text-7xl font-bold tracking-tightest text-text-primary">
          RESQ<span className="text-accent">-</span>NET
        </h1>
        <p className="mt-3 text-text-secondary text-sm tracking-micro uppercase">
          {t('selfHealing')}
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.6 }}
        className="absolute bottom-[8%] z-20 flex flex-col items-center gap-3"
      >
        <div className="w-48 h-[2px] bg-white/10 overflow-hidden rounded-full">
          <motion.div
            className="h-full bg-accent"
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{ duration: 2.5, ease: 'easeInOut' }}
          />
        </div>
        <p className="font-mono text-[10px] tracking-micro text-text-secondary uppercase">
          {t('initializing')}
        </p>
      </motion.div>
    </motion.div>
  )
}
