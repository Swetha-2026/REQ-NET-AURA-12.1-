import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AlertCircle, ArrowRight } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { useAuth } from '@/contexts/AuthContext'
import { demoCredentials, heroRobotImage } from '@/data/mockData'

export default function LoginScreen({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage()
  const { login, signup } = useAuth()
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    const result = mode === 'login' ? login(username, password) : signup(username, password)
    if (!result.success) setError(result.error || 'Unknown error')
  }

  const fillCredential = (user: string) => {
    setUsername(user)
    setPassword('demo123')
    setMode('login')
    setError('')
  }

  return (
    <motion.div
      className="fixed inset-0 z-50 flex bg-bg-primary noise-overlay overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Left: Robot visual */}
      <div className="hidden lg:block relative w-1/2 h-full overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse 80% 90% at 50% 50%, rgba(255,77,46,0.06) 0%, transparent 70%)',
          }}
        />
        <motion.img
          src={heroRobotImage}
          alt=""
          className="absolute inset-0 w-full h-full object-cover float-anim"
          style={{ filter: 'brightness(0.5) contrast(1.15)' }}
          initial={{ scale: 1.05, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.5 }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-bg-primary/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-transparent to-bg-primary/50" />

        {/* HUD overlays */}
        <div className="absolute top-12 left-12 z-10">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            className="font-mono text-[10px] tracking-micro text-text-secondary space-y-1"
          >
            <p>R01 <span className="text-text-primary ml-2">SENTINEL ONE</span></p>
            <p>{t('status')} <span className="text-success ml-2">● {t('online')}</span></p>
          </motion.div>
        </div>
        <div className="absolute bottom-12 left-12 z-10">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1 }}
            className="font-mono text-[10px] tracking-micro text-text-secondary space-y-1"
          >
            <p>{t('network')} <span className="text-text-primary ml-2">98.4%</span></p>
            <p>{t('signal')} <span className="text-text-primary ml-2">-42 dBm</span></p>
          </motion.div>
        </div>
      </div>

      {/* Right: Form */}
      <div className="relative flex-1 flex flex-col items-center justify-center px-6 sm:px-12 overflow-y-auto py-12">
        <div className="absolute inset-0 grid-pattern opacity-20 lg:hidden" />
        <div className="relative z-10 w-full max-w-md">
          {/* Brand */}
          <div className="mb-10">
            <button
              onClick={onBack}
              className="text-text-secondary hover:text-text-primary transition-colors text-xs tracking-micro uppercase mb-8"
            >
              ← {t('back')}
            </button>
            <h1 className="font-display text-4xl font-bold tracking-tightest text-text-primary">
              RESQ<span className="text-accent">-</span>NET
            </h1>
            <p className="mt-2 text-text-secondary text-sm">{t('selfHealing')}</p>
          </div>

          {/* Mode tabs */}
          <div className="flex gap-1 mb-8 border border-white/10 rounded-md p-1">
            {(['login', 'signup'] as const).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setError('') }}
                className={`flex-1 py-2.5 text-xs font-medium tracking-micro uppercase rounded transition-all ${
                  mode === m ? 'bg-accent text-white' : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                {m === 'login' ? t('signIn') : t('signUp')}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-[10px] tracking-micro text-text-secondary uppercase mb-2">
                {t('username')}
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-md text-text-primary font-mono text-sm focus:outline-none focus:border-accent/50 focus:bg-white/[0.05] transition-all"
                autoComplete="off"
              />
            </div>
            <div>
              <label className="block text-[10px] tracking-micro text-text-secondary uppercase mb-2">
                {t('password')}
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-md text-text-primary font-mono text-sm focus:outline-none focus:border-accent/50 focus:bg-white/[0.05] transition-all"
              />
            </div>

            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-center gap-2 text-error text-xs"
                >
                  <AlertCircle className="w-4 h-4" />
                  {error}
                </motion.div>
              )}
            </AnimatePresence>

            <button
              type="submit"
              className="group w-full flex items-center justify-center gap-2 py-3.5 bg-accent text-white font-display font-medium text-sm tracking-micro uppercase rounded-md hover:bg-accent-light transition-all duration-200 hover:shadow-[0_0_30px_rgba(255,77,46,0.25)]"
            >
              {mode === 'login' ? t('signIn') : t('signUp')}
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </form>

          {mode === 'login' && (
            <div className="mt-8">
              <p className="text-[10px] tracking-micro text-text-secondary uppercase mb-3">
                {t('demoCredentials')}
              </p>
              <div className="space-y-1.5">
                {demoCredentials.map((cred) => (
                  <button
                    key={cred.username}
                    onClick={() => fillCredential(cred.username)}
                    className="w-full flex items-center justify-between px-3 py-2 rounded border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/15 transition-all text-left"
                  >
                    <span className="font-mono text-xs text-text-primary">{cred.username}</span>
                    <span className="text-[10px] text-text-secondary tracking-micro uppercase">{cred.role}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}
