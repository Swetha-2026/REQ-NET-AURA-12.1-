import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '@/contexts/AuthContext'
import { useLanguage } from '@/contexts/LanguageContext'
import {
  LayoutDashboard, Map, Bot, Network, Route, MessageSquare, Bell,
  Users, Target, FlaskConical, BarChart3, User, Settings, LogOut,
  Menu, X, MoreHorizontal
} from 'lucide-react'
import type { UserRole } from '@/types'

const navIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  COMMAND: LayoutDashboard,
  MAP: Map,
  ROBOTS: Bot,
  NETWORK: Network,
  RESQPATH: Route,
  MESSAGES: MessageSquare,
  ALERTS: Bell,
  VICTIMS: Users,
  MISSIONS: Target,
  SIMULATION: FlaskConical,
  ANALYTICS: BarChart3,
  PROFILE: User,
  SETTINGS: Settings,
}

const mobileNav = ['COMMAND', 'MAP', 'ROBOTS', 'ALERTS', 'MORE']

export default function CommandCenter() {
  const { user, logout, accessiblePages } = useAuth()
  const { t } = useLanguage()
  const [activePage, setActivePage] = useState('COMMAND')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [currentTime, setCurrentTime] = useState('')

  useEffect(() => {
    const update = () => setCurrentTime(new Date().toLocaleTimeString('en-GB'))
    update()
    const timer = setInterval(update, 1000)
    return () => clearInterval(timer)
  }, [])

  const handleNavClick = (page: string) => {
    setActivePage(page)
    setSidebarOpen(false)
    setMobileNavOpen(false)
  }

  if (!user) return null

  const navItems = accessiblePages

  return (
    <div className="min-h-screen bg-bg-primary text-text-primary flex" dir={undefined}>
      {/* Sidebar - Desktop */}
      <aside className={`hidden lg:flex flex-col w-60 border-r border-white/8 bg-bg-secondary/50 backdrop-blur-sm fixed inset-y-0 z-30 transition-transform ${user ? 'translate-x-0' : ''}`}>
        <div className="px-6 py-5 border-b border-white/5">
          <h1 className="font-display text-lg font-bold tracking-tightest">
            RESQ<span className="text-accent">-</span>NET
          </h1>
        </div>
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
          {navItems.map((page) => {
            const Icon = navIcons[page] || LayoutDashboard
            const isActive = activePage === page
            return (
              <button
                key={page}
                onClick={() => handleNavClick(page)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-xs font-medium tracking-micro uppercase transition-all ${
                  isActive
                    ? 'bg-accent/10 text-accent border border-accent/20'
                    : 'text-text-secondary hover:text-text-primary hover:bg-white/[0.03] border border-transparent'
                }`}
              >
                <Icon className="w-4 h-4" />
                {t(page.toLowerCase())}
              </button>
            )
          })}
        </nav>
        <div className="px-3 py-4 border-t border-white/5">
          <div className="px-3 py-2 mb-2">
            <p className="text-[10px] text-text-secondary font-mono truncate">{user.name}</p>
            <p className="text-[9px] tracking-micro text-text-secondary/70 uppercase">{user.role}</p>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-xs font-medium tracking-micro uppercase text-text-secondary hover:text-error hover:bg-error/5 transition-all"
          >
            <LogOut className="w-4 h-4" />
            {t('close')}
          </button>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden fixed inset-0 bg-black/60 z-40"
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="lg:hidden flex flex-col w-64 border-r border-white/8 bg-bg-secondary fixed inset-y-0 left-0 z-50"
            >
              <div className="px-6 py-5 border-b border-white/5 flex items-center justify-between">
                <h1 className="font-display text-lg font-bold tracking-tightest">
                  RESQ<span className="text-accent">-</span>NET
                </h1>
                <button onClick={() => setSidebarOpen(false)}>
                  <X className="w-5 h-5 text-text-secondary" />
                </button>
              </div>
              <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
                {navItems.map((page) => {
                  const Icon = navIcons[page] || LayoutDashboard
                  const isActive = activePage === page
                  return (
                    <button
                      key={page}
                      onClick={() => handleNavClick(page)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-xs font-medium tracking-micro uppercase transition-all ${
                        isActive
                          ? 'bg-accent/10 text-accent border border-accent/20'
                          : 'text-text-secondary hover:text-text-primary hover:bg-white/[0.03] border border-transparent'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {t(page.toLowerCase())}
                    </button>
                  )
                })}
              </nav>
              <div className="px-3 py-4 border-t border-white/5">
                <button
                  onClick={logout}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-xs font-medium tracking-micro uppercase text-text-secondary hover:text-error hover:bg-error/5 transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  {t('close')}
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 lg:ml-60 flex flex-col min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-20 flex items-center justify-between px-4 sm:px-6 py-3 border-b border-white/5 bg-bg-primary/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 -ml-2 text-text-secondary hover:text-text-primary"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-success pulse-glow" />
              <span className="text-[10px] tracking-micro text-text-secondary uppercase hidden sm:inline">
                {t('network')} {t('status')} {t('online')}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-xs text-text-secondary">{currentTime}</span>
            <div className="flex items-center gap-2 px-3 py-1 rounded-md border border-accent/20 bg-accent/5">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" />
              <span className="text-[9px] tracking-micro text-accent uppercase font-medium">{t('critical')} 3</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto pb-20 lg:pb-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="p-4 sm:p-6 lg:p-8"
            >
              <PageRenderer page={activePage} role={user.role} onNavigate={handleNavClick} />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile bottom navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 flex items-center justify-around border-t border-white/8 bg-bg-secondary/95 backdrop-blur-md px-2 py-2">
        {mobileNav.map((page) => {
          const Icon = page === 'MORE' ? MoreHorizontal : navIcons[page] || LayoutDashboard
          const isActive = page === activePage || (page === 'MORE' && mobileNavOpen)
          if (page === 'MORE') {
            return (
              <button
                key={page}
                onClick={() => setMobileNavOpen(!mobileNavOpen)}
                className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-md transition-colors ${
                  isActive ? 'text-accent' : 'text-text-secondary'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[8px] tracking-micro uppercase">{t('more')}</span>
              </button>
            )
          }
          return (
            <button
              key={page}
              onClick={() => handleNavClick(page)}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-md transition-colors ${
                isActive ? 'text-accent' : 'text-text-secondary'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[8px] tracking-micro uppercase">{t(page.toLowerCase())}</span>
            </button>
          )
        })}
      </nav>

      {/* Mobile "more" panel */}
      <AnimatePresence>
        {mobileNavOpen && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="lg:hidden fixed bottom-16 left-0 right-0 z-30 glass-strong rounded-t-xl p-4 pb-6"
          >
            <div className="grid grid-cols-3 gap-2">
              {navItems.filter((p) => !mobileNav.includes(p)).map((page) => {
                const Icon = navIcons[page] || LayoutDashboard
                return (
                  <button
                    key={page}
                    onClick={() => handleNavClick(page)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-lg border transition-all ${
                      activePage === page
                        ? 'bg-accent/10 border-accent/20 text-accent'
                        : 'border-white/5 text-text-secondary hover:bg-white/[0.03]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-[8px] tracking-micro uppercase">{t(page.toLowerCase())}</span>
                  </button>
                )
              })}
            </div>
            <button
              onClick={logout}
              className="w-full mt-4 flex items-center justify-center gap-2 py-2.5 rounded-md text-xs font-medium tracking-micro uppercase text-text-secondary hover:text-error hover:bg-error/5 transition-all"
            >
              <LogOut className="w-4 h-4" />
              {t('close')}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function PageRenderer({ page, role, onNavigate }: { page: string; role: UserRole; onNavigate: (page: string) => void }) {
  const { t } = useLanguage()
  switch (page) {
    case 'COMMAND':
      return <CommandDashboard onNavigate={onNavigate} />
    case 'MAP':
      return <TacticalMap />
    case 'ROBOTS':
      return <RobotOperations />
    case 'NETWORK':
      return <NetworkPage />
    case 'RESQPATH':
      return <ResQPathPage />
    case 'MESSAGES':
      return <MessagesPage />
    case 'ALERTS':
      return <AlertsPage />
    case 'VICTIMS':
      return <VictimsPage />
    case 'MISSIONS':
      return <MissionsPage />
    case 'SIMULATION':
      return <SimulationPage />
    case 'ANALYTICS':
      return <AnalyticsPage />
    case 'PROFILE':
      return <ProfilePage />
    case 'SETTINGS':
      return <SettingsPage />
    default:
      return <div className="text-text-secondary">{t('noData')}</div>
  }
}

import CommandDashboard from '@/pages/dashboard/CommandDashboard'
import TacticalMap from '@/pages/dashboard/TacticalMap'
import RobotOperations from '@/pages/dashboard/RobotOperations'
import NetworkPage from '@/pages/dashboard/NetworkPage'
import ResQPathPage from '@/pages/dashboard/ResQPathPage'
import MessagesPage from '@/pages/dashboard/MessagesPage'
import AlertsPage from '@/pages/dashboard/AlertsPage'
import VictimsPage from '@/pages/dashboard/VictimsPage'
import MissionsPage from '@/pages/dashboard/MissionsPage'
import SimulationPage from '@/pages/dashboard/SimulationPage'
import AnalyticsPage from '@/pages/dashboard/AnalyticsPage'
import ProfilePage from '@/pages/dashboard/ProfilePage'
import SettingsPage from '@/pages/dashboard/SettingsPage'
