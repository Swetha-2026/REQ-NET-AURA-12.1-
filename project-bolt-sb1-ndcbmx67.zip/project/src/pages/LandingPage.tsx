import { motion, useScroll, useTransform } from 'framer-motion'
import { useRef, useEffect, useState } from 'react'
import { ArrowRight, Activity, Wifi, Radio, AlertTriangle, ChevronDown } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { heroRobotImage, robots, robotImages, disasterImages } from '@/data/mockData'

export default function LandingPage({ onEnter }: { onEnter: () => void }) {
  const { t } = useLanguage()
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll()
  const heroY = useTransform(scrollYProgress, [0, 0.3], [0, 100])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])
  const robotScale = useTransform(scrollYProgress, [0, 0.3], [1, 1.15])

  const [resqPathStep, setResqPathStep] = useState(0)
  useEffect(() => {
    const timer = setInterval(() => {
      setResqPathStep((s) => (s + 1) % 4)
    }, 2500)
    return () => clearInterval(timer)
  }, [])

  return (
    <div ref={containerRef} className="relative bg-bg-primary text-text-primary">
      {/* Top Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 px-6 sm:px-10 py-5">
        <div className="flex items-center justify-between max-w-screen-2xl mx-auto">
          <h1 className="font-display text-xl font-bold tracking-tightest">
            RESQ<span className="text-accent">-</span>NET
          </h1>
          <div className="hidden md:flex items-center gap-8">
            {['operations', 'network', 'resqpath', 'missions', 'about'].map((item) => (
              <a
                key={item}
                href={`#${item}`}
                className="text-[10px] tracking-micro text-text-secondary hover:text-text-primary transition-colors uppercase"
              >
                {t(item)}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-success pulse-glow" />
            <span className="text-[10px] tracking-micro text-text-secondary uppercase">{t('status')} {t('online')}</span>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse 70% 80% at 70% 50%, rgba(255,77,46,0.08) 0%, transparent 60%)',
          }}
        />

        {/* Robot image */}
        <motion.div
          style={{ scale: robotScale }}
          className="absolute right-0 top-0 bottom-0 w-full md:w-[55%] lg:w-[50%] flex items-center justify-end overflow-hidden"
        >
          <motion.img
            src={heroRobotImage}
            alt="Rescue Robot"
            className="w-full h-full object-cover float-anim"
            style={{ filter: 'brightness(0.55) contrast(1.15)' }}
            initial={{ x: 80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
          />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent via-bg-primary/30 to-bg-primary" />
          <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-transparent to-bg-primary/60" />
        </motion.div>

        {/* Hero content */}
        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 w-full md:w-[55%] lg:w-[50%] px-6 sm:px-10 lg:px-20"
        >
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="font-mono text-xs tracking-micro text-accent mb-6"
          >
            RESQ-NET
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="font-display font-bold tracking-tightest text-text-primary leading-[0.95] text-5xl sm:text-7xl lg:text-8xl"
          >
            {t('theNetwork')}
            <br />
            <span className="text-text-primary">{t('thatDoesntStop')}</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-6 text-text-secondary text-base sm:text-lg max-w-md leading-relaxed"
          >
            {t('heroSubtext')}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mt-10 flex flex-col sm:flex-row gap-3"
          >
            <button
              onClick={onEnter}
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-accent text-white font-display font-medium text-sm tracking-micro uppercase rounded-md hover:bg-accent-light transition-all duration-200 hover:shadow-[0_0_40px_rgba(255,77,46,0.3)]"
            >
              {t('enterCommandCenter')}
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
            <a
              href="#resqpath"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-white/15 text-text-primary font-display font-medium text-sm tracking-micro uppercase rounded-md hover:bg-white/[0.05] hover:border-white/25 transition-all"
            >
              {t('exploreResqPath')}
            </a>
          </motion.div>
        </motion.div>

        {/* HUD overlays on robot */}
        <motion.div
          style={{ opacity: heroOpacity }}
          className="absolute top-[20%] right-[8%] z-10 hidden lg:block"
        >
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.2 }}
            className="glass-strong px-4 py-3 rounded-md font-mono text-[10px] tracking-micro text-text-secondary space-y-1.5 min-w-[140px]"
          >
            <p className="text-text-primary font-medium">R01</p>
            <p>SENTINEL ONE</p>
            <div className="h-px bg-white/10 my-1.5" />
            <p>{t('network')} <span className="text-success ml-1">98.4%</span></p>
            <p>{t('latency')} <span className="text-text-primary ml-1">42ms</span></p>
            <p>{t('signal')} <span className="text-text-primary ml-1">-42dBm</span></p>
            <p>{t('status')} <span className="text-success ml-1">● {t('online')}</span></p>
          </motion.div>
        </motion.div>

        <motion.div
          style={{ opacity: heroOpacity }}
          className="absolute bottom-[18%] right-[15%] z-10 hidden lg:block"
        >
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.5 }}
            className="flex items-center gap-2"
          >
            <div className="w-2 h-2 rounded-full bg-accent pulse-glow" />
            <span className="font-mono text-[9px] tracking-micro text-text-secondary uppercase">Sensor Active</span>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          style={{ opacity: heroOpacity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        >
          <ChevronDown className="w-5 h-5 text-text-secondary animate-bounce" />
        </motion.div>
      </section>

      {/* Problem Section */}
      <section id="operations" className="relative min-h-screen flex items-center py-32 overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-20 w-full">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <p className="font-mono text-[10px] tracking-micro text-accent mb-6 uppercase">01 — {t('operations')}</p>
              <h2 className="font-display font-bold tracking-tightest text-4xl sm:text-6xl leading-[0.95]">
                {t('problemHeading')}
                <br />
                <span className="text-text-secondary">{t('problemHeading2')}</span>
              </h2>
              <p className="mt-8 text-text-secondary text-base sm:text-lg leading-relaxed max-w-lg">
                {t('problemBody')}
              </p>
              <div className="mt-10 flex items-center gap-4">
                <AlertTriangle className="w-5 h-5 text-accent" />
                <span className="font-mono text-xs tracking-micro text-text-secondary uppercase">
                  RESQ-NET CREATES THE LAYER THAT SURVIVES
                </span>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 1.1 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="relative aspect-[4/5] rounded-2xl overflow-hidden"
            >
              <img
                src={disasterImages.earthquake}
                alt="Disaster zone"
                className="w-full h-full object-cover"
                style={{ filter: 'brightness(0.6) contrast(1.1)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <p className="font-mono text-[10px] tracking-micro text-text-secondary uppercase">DISASTER ZONE — ZONE C</p>
                <p className="font-display text-2xl font-bold text-text-primary mt-1">SECTOR 7</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ResQPath Section */}
      <section id="resqpath" className="relative min-h-screen flex items-center py-32 overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse 50% 60% at 50% 50%, rgba(255,77,46,0.06) 0%, transparent 70%)',
          }}
        />
        <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10 lg:px-20 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <p className="font-mono text-[10px] tracking-micro text-accent mb-4 uppercase">02 — RESQPATH</p>
            <h2 className="font-display font-bold tracking-tightest text-4xl sm:text-7xl leading-[0.95]">
              {t('resqPathHeading')}
              <br />
              <span className="text-accent">{t('resqPathHeading2')}</span>
            </h2>
            <p className="mt-6 text-text-secondary text-base max-w-xl mx-auto leading-relaxed">
              {t('resqPathBody')}
            </p>
          </motion.div>

          {/* Network visualization */}
          <ResQPathVisualization step={resqPathStep} t={t} />
        </div>
      </section>

      {/* Robot Network Section */}
      <section id="network" className="relative min-h-screen flex items-center py-32 overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-20 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <p className="font-mono text-[10px] tracking-micro text-accent mb-4 uppercase">03 — {t('network')}</p>
            <h2 className="font-display font-bold tracking-tightest text-4xl sm:text-6xl leading-[0.95]">
              {t('robotNetworkHeading')}
            </h2>
            <p className="mt-4 text-text-secondary text-base max-w-lg">{t('robotNetworkSubtext')}</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {robots.map((robot, idx) => (
              <motion.div
                key={robot.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1, duration: 0.6 }}
                className="group relative aspect-[4/5] rounded-xl overflow-hidden border border-white/5 hover:border-white/15 transition-all"
              >
                <img
                  src={robotImages[robot.id]}
                  alt={robot.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  style={{ filter: 'brightness(0.5) contrast(1.1)' }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/20 to-transparent" />
                {robot.status === 'OFFLINE' && (
                  <div className="absolute inset-0 bg-error/20" />
                )}
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-display text-lg font-bold text-text-primary">{robot.id}</p>
                    <span className={`w-2 h-2 rounded-full ${
                      robot.status === 'ONLINE' ? 'bg-success' : robot.status === 'WARNING' ? 'bg-warning' : 'bg-error'
                    } ${robot.status === 'ONLINE' ? 'pulse-glow' : ''}`} />
                  </div>
                  <p className="text-sm text-text-primary font-medium">{robot.name}</p>
                  <p className="text-[10px] tracking-micro text-text-secondary uppercase mt-1">{robot.role}</p>
                  <div className="flex items-center gap-4 mt-4 text-[10px] font-mono text-text-secondary">
                    <span>{robot.battery}%</span>
                    <span>{robot.rssi}dBm</span>
                    <span>{robot.latency}ms</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Command Center CTA */}
      <section id="missions" className="relative min-h-[80vh] flex items-center py-32 overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse 60% 70% at 30% 50%, rgba(255,77,46,0.06) 0%, transparent 70%)',
          }}
        />
        <div className="relative z-10 max-w-5xl mx-auto px-6 sm:px-10 lg:px-20 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <p className="font-mono text-[10px] tracking-micro text-accent mb-6 uppercase">04 — {t('commandCenterHeading')}</p>
            <h2 className="font-display font-bold tracking-tightest text-4xl sm:text-6xl leading-[0.95] max-w-3xl">
              {t('commandCenterBody')}
            </h2>
            <button
              onClick={onEnter}
              className="group mt-12 inline-flex items-center justify-center gap-3 px-10 py-5 bg-accent text-white font-display font-medium text-base tracking-micro uppercase rounded-md hover:bg-accent-light transition-all duration-200 hover:shadow-[0_0_50px_rgba(255,77,46,0.35)]"
            >
              {t('enterCommandCenter')}
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* Final CTA */}
      <section id="about" className="relative min-h-[60vh] flex items-center py-32 overflow-hidden border-t border-white/5">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        <div className="relative z-10 max-w-5xl mx-auto px-6 sm:px-10 lg:px-20 w-full text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-display font-bold tracking-tightest text-3xl sm:text-5xl leading-[0.95]">
              {t('finalCtaHeading')}
              <br />
              <span className="text-accent">{t('finalCtaHeading2')}</span>
            </h2>
            <p className="mt-6 text-text-secondary text-sm font-mono tracking-micro uppercase">
              RESQ-NET — {t('selfHealing')}
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

function ResQPathVisualization({ step, t }: { step: number; t: (key: string) => string }) {
  const steps = [
    t('linkFailureDetected'),
    t('analyzingNetwork'),
    t('alternativePathFound'),
    t('routeRestored'),
  ]

  const nodes = [
    { id: 'CONTROL', label: 'CONTROL', x: 50, y: 8 },
    { id: 'R01', label: 'R01', x: 50, y: 28 },
    { id: 'R02', label: 'R02', x: 25, y: 48 },
    { id: 'R05', label: 'R05', x: 75, y: 48 },
    { id: 'R03', label: 'R03', x: 15, y: 72 },
    { id: 'R04', label: 'R04', x: 70, y: 72 },
    { id: 'TARGET', label: 'TARGET', x: 50, y: 92 },
  ]

  const links: { from: string; to: string; status: 'online' | 'failed' | 'recovered' }[] = [
    { from: 'CONTROL', to: 'R01', status: 'online' },
    { from: 'R01', to: 'R02', status: 'online' },
    { from: 'R01', to: 'R05', status: 'online' },
    { from: 'R02', to: 'R03', status: step >= 0 ? 'failed' : 'online' },
    { from: 'R02', to: 'R05', status: step >= 2 ? 'recovered' : 'online' },
    { from: 'R05', to: 'R04', status: step >= 2 ? 'recovered' : 'online' },
    { from: 'R03', to: 'R04', status: 'failed' },
    { from: 'R04', to: 'TARGET', status: step >= 2 ? 'recovered' : 'online' },
  ]

  const getNode = (id: string) => nodes.find((n) => n.id === id)!

  return (
    <div className="relative">
      <div className="relative aspect-square max-w-2xl mx-auto">
        <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
          {links.map((link, i) => {
            const from = getNode(link.from)
            const to = getNode(link.to)
            const isFailed = link.status === 'failed'
            const isRecovered = link.status === 'recovered'
            const color = isFailed ? '#FF4D2E' : isRecovered ? '#FF7048' : '#8B9298'
            return (
              <g key={i}>
                <line
                  x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                  stroke={color}
                  strokeWidth={isFailed ? 0.4 : 0.6}
                  strokeDasharray={isFailed ? '1.5 1.5' : undefined}
                  opacity={isFailed ? 0.6 : 0.8}
                  className={isRecovered ? 'dash-anim' : ''}
                />
              </g>
            )
          })}
        </svg>

        {nodes.map((node) => {
          const isFailed = node.id === 'R03'
          const isRelay = node.id === 'R05' && step >= 2
          return (
            <div
              key={node.id}
              className="absolute flex flex-col items-center"
              style={{
                left: `${node.x}%`,
                top: `${node.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              <div
                className={`w-12 h-12 sm:w-14 sm:h-14 rounded-lg flex items-center justify-center font-mono text-xs font-medium border transition-all duration-500 ${
                  isFailed
                    ? 'bg-error/20 border-error/40 text-error'
                    : isRelay
                    ? 'bg-accent/20 border-accent/50 text-accent pulse-glow'
                    : node.id === 'CONTROL' || node.id === 'TARGET'
                    ? 'glass-strong border-white/20 text-text-primary'
                    : 'glass border-white/10 text-text-secondary'
                }`}
              >
                {node.label.slice(0, 6)}
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-8 text-center">
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-3 px-6 py-3 glass rounded-md"
        >
          <div className={`w-2 h-2 rounded-full ${
            step === 0 ? 'bg-error' : step === 1 ? 'bg-warning' : 'bg-success'
          } pulse-glow`} />
          <span className="font-mono text-xs tracking-micro text-text-primary uppercase">
            {steps[step]}
          </span>
        </motion.div>
        <div className="flex justify-center gap-2 mt-4">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`h-1 rounded-full transition-all duration-300 ${
                i === step ? 'w-8 bg-accent' : 'w-2 bg-white/15'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
