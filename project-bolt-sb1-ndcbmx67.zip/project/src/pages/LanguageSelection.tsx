import { motion } from 'framer-motion'
import { Check } from 'lucide-react'
import { useLanguage, languages } from '@/contexts/LanguageContext'
import type { LanguageCode } from '@/data/translations'

export default function LanguageSelection({ onSelect }: { onSelect: () => void }) {
  const { lang, setLang, t } = useLanguage()

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-bg-primary noise-overlay overflow-y-auto py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="absolute inset-0 grid-pattern opacity-30" />
      <div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse 50% 60% at 50% 40%, rgba(255,77,46,0.06) 0%, transparent 70%)',
        }}
      />

      <div className="relative z-10 w-full max-w-4xl px-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-12"
        >
          <p className="font-mono text-[10px] tracking-micro text-accent mb-3">RESQ-NET</p>
          <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tightest text-text-primary">
            {t('selectLanguage')}
          </h2>
          <p className="mt-4 text-text-secondary text-sm">
            {t('pickLanguagePrompt')}
          </p>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {languages.map((language, idx) => (
            <motion.button
              key={language.code}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.1 + idx * 0.03 }}
              onClick={() => setLang(language.code as LanguageCode)}
              className={`group relative flex items-center justify-between px-5 py-4 rounded-lg border transition-all duration-200 text-left ${
                lang === language.code
                  ? 'border-accent/50 bg-accent/10'
                  : 'border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.04]'
              }`}
            >
              <div>
                <p className="font-display text-base font-medium text-text-primary">
                  {language.nativeName}
                </p>
                <p className="text-[10px] text-text-secondary tracking-micro uppercase mt-1">
                  {language.name}
                </p>
              </div>
              {lang === language.code && (
                <Check className="w-4 h-4 text-accent" />
              )}
            </motion.button>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <button
            onClick={onSelect}
            className="group inline-flex items-center gap-3 px-8 py-3.5 bg-accent text-white font-display font-medium text-sm tracking-micro uppercase rounded-md hover:bg-accent-light transition-all duration-200 hover:shadow-[0_0_30px_rgba(255,77,46,0.3)]"
          >
            {t('continue')}
            <span className="transition-transform group-hover:translate-x-1">→</span>
          </button>
        </motion.div>
      </div>
    </motion.div>
  )
}
