import { useState, useEffect } from 'react'
import { AnimatePresence } from 'framer-motion'
import { LanguageProvider } from '@/contexts/LanguageContext'
import { AuthProvider, useAuth } from '@/contexts/AuthContext'
import SplashScreen from '@/pages/SplashScreen'
import LanguageSelection from '@/pages/LanguageSelection'
import LoginScreen from '@/pages/LoginScreen'
import LandingPage from '@/pages/LandingPage'
import CommandCenter from '@/pages/CommandCenter'

type Flow = 'splash' | 'language' | 'login' | 'landing' | 'command'

function AppContent() {
  const { user } = useAuth()
  const [flow, setFlow] = useState<Flow>('splash')
  const [languageSelected, setLanguageSelected] = useState(false)

  useEffect(() => {
    if (user && flow !== 'command') {
      setFlow('command')
    }
  }, [user, flow])

  useEffect(() => {
    if (flow === 'splash') {
      const timer = setTimeout(() => {
        const stored = localStorage.getItem('resq-language')
        if (stored) {
          setLanguageSelected(true)
          setFlow('landing')
        } else {
          setFlow('language')
        }
      }, 3500)
      return () => clearTimeout(timer)
    }
  }, [flow])

  const handleLanguageSelect = () => {
    setLanguageSelected(true)
    setFlow('login')
  }

  const handleEnterCommand = () => {
    if (user) {
      setFlow('command')
    } else {
      setFlow('login')
    }
  }

  if (user && flow !== 'command') {
    setFlow('command')
  }

  return (
    <AnimatePresence mode="wait">
      {flow === 'splash' && <SplashScreen key="splash" onComplete={() => {}} />}
      {flow === 'language' && (
        <LanguageSelection key="language" onSelect={handleLanguageSelect} />
      )}
      {flow === 'login' && (
        <LoginScreen key="login" onBack={() => setFlow('landing')} />
      )}
      {flow === 'landing' && (
        <LandingPage key="landing" onEnter={handleEnterCommand} />
      )}
      {flow === 'command' && user && <CommandCenter key="command" />}
    </AnimatePresence>
  )
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  )
}
