import type { Config } from 'tailwindcss'

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'bg-primary': '#07090B',
        'bg-secondary': '#0D1013',
        'bg-surface': '#12161A',
        'text-primary': '#F5F5F0',
        'text-secondary': '#8B9298',
        'accent': {
          DEFAULT: '#FF4D2E',
          light: '#FF7048',
          dark: '#CC3D24',
        },
        'success': '#3DD68C',
        'warning': '#FFB54D',
        'error': '#FF4D2E',
        'info': '#5BA8E5',
      },
      fontFamily: {
        display: ['Space Grotesk', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
    },
  },
  plugins: [],
} satisfies Config
